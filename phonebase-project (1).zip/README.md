# PhoneBase — server ala Firebase yang jalan di HP Android

PhoneBase mengubah HP Android menjadi server backend:

- **Database dokumen** (koleksi + dokumen JSON, seperti Firestore) dengan filter, urutan, dan halaman
- **Login pengguna** (daftar, login, token)
- **Penyimpanan file** (unggah foto/dokumen)
- **Realtime**: perubahan data dan pesan channel langsung sampai ke aplikasi lain
- **Dashboard web** untuk mengontrol semuanya dari browser (HP/laptop mana pun)
- **Aplikasi APK**: nyalakan/matikan server, lihat alamat & password admin, dan bisa membuka dashboard server lain

## 1. Membuat APK (sekali saja)

1. Buat repository baru di GitHub (boleh private).
2. Upload **semua isi folder ini** ke repository tersebut.
3. Pastikan ada file `.github/workflows/build.yml`. Folder yang diawali titik kadang tidak ikut terupload.
   Kalau tidak ada: di GitHub klik **Add file → Create new file**, ketik nama `.github/workflows/build.yml`,
   lalu salin isi file `workflow-build.yml` dari folder ini.
4. Buka tab **Actions** → tunggu workflow **Build APK** selesai (hijau, sekitar 3-6 menit).
   Kalau belum jalan sendiri, pilih **Build APK → Run workflow**.
5. Buka run yang selesai, scroll ke **Artifacts**, unduh **phonebase-apk**, ekstrak, dan pasang `app-debug.apk` di HP.
   (Android akan meminta izin "install dari sumber tidak dikenal".)

Workflow otomatis mencari `settings.gradle`, jadi boleh upload isi folder langsung ke root repository, di dalam subfolder, atau upload file ZIP-nya saja.
Kalau build gagal, salin pesan error merahnya ke Claude supaya diperbaiki.

## 2. Menjalankan server di HP

1. Buka aplikasi **PhoneBase**, izinkan notifikasi.
2. Tekan **Izinkan jalan terus di latar belakang** dan pilih izinkan (penting supaya Android tidak mematikan server).
3. Tekan **Nyalakan server**. Alamat server tampil, misalnya `http://192.168.1.5:8080`.
4. **Password admin** tampil di layar aplikasi (acak, dibuat otomatis). Bisa diganti di dashboard.
5. Tekan **Buka dashboard (HP ini)**, atau dari laptop/HP lain di Wi-Fi yang sama buka alamat tadi di browser.

Tips untuk HP server: colok charger terus, matikan penghematan baterai untuk PhoneBase,
dan centang **Nyalakan otomatis saat HP menyala** bila perlu.

## 3. Mengontrol dari HP Android lain (APK)

Pasang APK yang sama di HP lain, isi alamat server di bagian **Kontrol server lain**, lalu login dengan password admin.

## 4. Akses dari internet

HP biasanya ada di belakang jaringan operator/router sehingga tidak bisa dijangkau langsung. Dua cara yang aman:

**A. Tailscale (pribadi, paling aman, paling mudah)**
Pasang aplikasi Tailscale di HP server dan di perangkat lain, login dengan akun yang sama.
Pakai alamat Tailscale HP server (mis. `http://100.x.y.z:8080`). Hanya perangkat Anda yang bisa mengakses.

**B. Cloudflare Tunnel (publik, berbasis HTTPS)**
Untuk aplikasi yang dipakai banyak orang. Di Termux di HP yang sama, pasang `cloudflared` lalu jalankan
`cloudflared tunnel --url http://localhost:8080` untuk mendapat alamat `https://....trycloudflare.com` sementara.
Untuk alamat tetap, buat tunnel dengan domain sendiri di akun Cloudflare.

Jangan membuka port router langsung ke internet tanpa HTTPS: data dan password akan lewat tanpa enkripsi.

## 5. Memakai dari aplikasi/situs

Di halaman web atau WebView:

```html
<script src="http://ALAMAT-SERVER:8080/phonebase.js"></script>
<script>
  const pb = PhoneBase("http://ALAMAT-SERVER:8080");
  await pb.register("user@mail.com", "rahasia123");   // atau pb.login(...)
  const todos = pb.collection("todos");
  await todos.add({ judul: "Beli susu", selesai: false });
  const hasil = await todos.list({ where: ["selesai:eq:false"], order: "-_created" });
  todos.listen(e => console.log(e.type, e.id, e.data));   // realtime
  pb.channel("umum").publish("halo");                      // pesan realtime
</script>
```

Atau lewat HTTP biasa (curl, Postman, aplikasi apa pun):

```
POST /api/auth/register   {"email","password"}      -> {token, user}
POST /api/auth/login      {"email","password"}      -> {token, user}
GET  /api/db/{koleksi}?where=umur:gt:17&order=-_created&limit=20
     (sub-koleksi: /api/db/{koleksi}/{id}/{sub}/{id2} ...)
POST /api/db/{koleksi}                               (tambah dokumen)
GET|PUT|PATCH|DELETE /api/db/{koleksi}/{id}
GET  /api/realtime?col={koleksi}&token=...           (SSE)
POST /api/channels/{nama}/publish   {"message": ...}
POST /api/files?name=foto.jpg                        (body = isi file)
GET  /api/files/{id}?token=...
```

Kirim token dengan header `Authorization: Bearer TOKEN`. Operator filter: `eq, ne, gt, gte, lt, lte, contains`.

## 6. Dashboard ala Firebase

Buka dashboard dari browser (alamat server) atau dari aplikasi. Menu di kiri:

- **Database → Data**: panel 3 kolom seperti Firestore (koleksi → dokumen → field). Ada **Mulai koleksi**, **Tambah dokumen**, **Tambah field** (string, number, boolean, null, map, array), ubah/hapus field, filter, dan **sub-koleksi** di dalam dokumen. Perubahan dari aplikasi lain muncul otomatis (realtime).
- **Database → Aturan**: editor aturan akses dengan nomor baris, **riwayat versi** (pilih versi lama lalu *Publikasikan* untuk memakainya lagi), dan **Develop & Test** untuk mencoba aturan sebelum dipublikasikan.
- **Database → Penggunaan**: jumlah dokumen, ukuran database, koneksi, request.
- **Autentikasi**: daftar pengguna, tambah, nonaktifkan, reset password, hapus.
- **Penyimpanan**: file yang diunggah. **Pesan realtime**: kirim/dengar channel.

Sub-koleksi dipakai lewat path, misalnya `users/UID/banks`:
`pb.collection("users/" + uid + "/banks").add({ nama: "BCA" })`.

## 7. Aturan akses

Contoh isi tab **Aturan**:

```
rules_version = '1';
service phonebase {
  match /{document=**} {          // aturan bawaan untuk semua koleksi
    allow read, write: if signedIn();
  }
  match /users/{doc} {
    allow read: if signedIn();
    allow write: if isOwner();
  }
  match /_files/{doc} {           // file
    allow read: if true;
    allow write: if signedIn();
  }
}
```

Kondisi yang dikenal: `true`, `signedIn()` (harus login), `isOwner()` (hanya pembuat dokumen, khusus write), `isAdmin()` / `false` (hanya admin).
Aturan sebuah koleksi berlaku juga untuk semua sub-koleksinya. Admin selalu boleh. Operasi yang tidak ditulis di sebuah blok ditolak.
Target khusus: `/_files/{doc}` untuk file dan `/ch:nama/{doc}` untuk channel pesan.
Ini versi sederhana dari bahasa Firestore Rules: kondisi lain (mis. membandingkan field) belum didukung, dan editor akan menolak dengan pesan yang jelas.

## Keterbatasan yang perlu diketahui

- Filter dan pengurutan dilakukan di dalam server setelah membaca satu koleksi, jadi nyaman untuk puluhan ribu dokumen, bukan jutaan.
- Server hanya hidup selama HP menyala, terhubung internet, dan tidak dimatikan sistem. Kualitas HP/baterai/operator menentukan.
- Data tersimpan di dalam HP. Belum ada backup otomatis, jadi salin/ekspor data penting secara berkala.
- Tanpa HTTPS, lalu lintas lewat Wi-Fi lokal tidak terenkripsi. Untuk internet, gunakan Tailscale atau Cloudflare Tunnel.
- APK ini adalah versi *debug* (cukup untuk dipakai sendiri).
