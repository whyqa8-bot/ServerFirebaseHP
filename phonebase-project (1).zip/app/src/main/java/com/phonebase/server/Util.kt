package com.phonebase.server

import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class ApiException(val code: Int, message: String) : Exception(message)

class Principal(val kind: String, val userId: String?, val email: String?) {
    val isAdmin: Boolean
        get() = kind == "admin"
    val isAuthed: Boolean
        get() = kind != "anon"
}

object Util {
    private val rnd = SecureRandom()
    private const val ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789"

    fun randomId(len: Int): String {
        val sb = StringBuilder()
        for (i in 0 until len) {
            sb.append(ALPHABET[rnd.nextInt(ALPHABET.length)])
        }
        return sb.toString()
    }

    fun randomToken(): String {
        val b = ByteArray(24)
        rnd.nextBytes(b)
        return toHex(b)
    }

    fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (x in bytes) {
            val v = x.toInt() and 0xff
            if (v < 16) sb.append('0')
            sb.append(Integer.toHexString(v))
        }
        return sb.toString()
    }

    fun hashPassword(password: String, salt: String): String {
        val spec = PBEKeySpec(password.toCharArray(), salt.toByteArray(Charsets.UTF_8), 10000, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        return toHex(factory.generateSecret(spec).encoded)
    }

    fun safeEquals(a: String, b: String): Boolean {
        return MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
    }

    fun localIps(): List<String> {
        val out = ArrayList<String>()
        try {
            val en = NetworkInterface.getNetworkInterfaces()
            while (en != null && en.hasMoreElements()) {
                val ni = en.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        val h = a.hostAddress
                        if (h != null && h.isNotEmpty()) out.add(h)
                    }
                }
            }
        } catch (e: Exception) {
            // abaikan
        }
        return out
    }
}

/** Pembatas percobaan login gagal (anti tebak password). */
object Limiter {
    private val fails = HashMap<String, ArrayList<Long>>()
    private const val WINDOW_MS = 10L * 60L * 1000L
    private const val MAX_FAILS = 8

    @Synchronized
    fun blocked(key: String): Boolean {
        val list = fails[key] ?: return false
        val cutoff = System.currentTimeMillis() - WINDOW_MS
        val keep = ArrayList<Long>()
        for (t in list) {
            if (t >= cutoff) keep.add(t)
        }
        fails[key] = keep
        return keep.size >= MAX_FAILS
    }

    @Synchronized
    fun fail(key: String) {
        if (fails.size > 2000) fails.clear()
        var list = fails[key]
        if (list == null) {
            list = ArrayList()
            fails[key] = list
        }
        list.add(System.currentTimeMillis())
    }

    @Synchronized
    fun clear(key: String) {
        fails.remove(key)
    }
}
