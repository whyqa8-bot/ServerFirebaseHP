package com.phonebase.server

import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Penyimpanan data (SQLite): dokumen, pengguna, sesi, file, aturan akses, pengaturan. */
class Store private constructor(context: Context) :
    SQLiteOpenHelper(context, "phonebase.db", null, 2) {

    val filesDir: File = File(context.filesDir, "uploads")

    init {
        filesDir.mkdirs()
        setWriteAheadLoggingEnabled(true)
    }

    companion object {
        private const val RULES_HISTORY_SQL =
            "CREATE TABLE IF NOT EXISTS rules_history (version INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "body TEXT NOT NULL, created INTEGER NOT NULL)"

        @Volatile
        private var instance: Store? = null

        fun get(context: Context): Store {
            val existing = instance
            if (existing != null) return existing
            synchronized(this) {
                val again = instance
                if (again != null) return again
                val created = Store(context.applicationContext)
                instance = created
                return created
            }
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE docs (col TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL, " +
                "owner TEXT, created INTEGER NOT NULL, updated INTEGER NOT NULL, PRIMARY KEY (col, id))"
        )
        db.execSQL("CREATE INDEX idx_docs_created ON docs (col, created)")
        db.execSQL(
            "CREATE TABLE users (id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, " +
                "hash TEXT NOT NULL, created INTEGER NOT NULL, disabled INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE TABLE sessions (token TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires INTEGER NOT NULL)")
        db.execSQL(
            "CREATE TABLE files (id TEXT PRIMARY KEY, name TEXT NOT NULL, mime TEXT NOT NULL, " +
                "size INTEGER NOT NULL, owner TEXT, created INTEGER NOT NULL)"
        )
        db.execSQL("CREATE TABLE rules (col TEXT PRIMARY KEY, can_read TEXT NOT NULL, can_write TEXT NOT NULL)")
        db.execSQL("CREATE TABLE settings (k TEXT PRIMARY KEY, v TEXT)")
        db.execSQL(RULES_HISTORY_SQL)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL(RULES_HISTORY_SQL)
    }

    private fun now(): Long = System.currentTimeMillis()

    // ------------------------------------------------------------ pengaturan

    fun settingGet(key: String, def: String): String {
        val c = readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(key))
        try {
            if (c.moveToFirst()) {
                val v = c.getString(0)
                if (v != null) return v
            }
        } finally {
            c.close()
        }
        return def
    }

    fun settingSet(key: String, value: String) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO settings (k, v) VALUES (?, ?)",
            arrayOf<Any>(key, value)
        )
    }

    // ------------------------------------------------------------ admin

    fun ensureAdmin() {
        if (settingGet("admin_hash", "").isEmpty()) {
            val pw = Util.randomId(10)
            setAdminPassword(pw)
            settingSet("admin_pw_plain", pw)
        }
    }

    fun setAdminPassword(pw: String) {
        val salt = Util.randomToken()
        settingSet("admin_salt", salt)
        settingSet("admin_hash", Util.hashPassword(pw, salt))
        settingSet("admin_pw_plain", "")
    }

    fun verifyAdmin(pw: String): Boolean {
        val salt = settingGet("admin_salt", "")
        val hash = settingGet("admin_hash", "")
        if (salt.isEmpty() || hash.isEmpty()) return false
        return Util.safeEquals(Util.hashPassword(pw, salt), hash)
    }

    fun adminPasswordPlain(): String = settingGet("admin_pw_plain", "")

    // ------------------------------------------------------------ pengguna

    fun createUser(email: String, password: String): JSONObject? {
        val id = Util.randomId(16)
        val salt = Util.randomToken()
        val hash = Util.hashPassword(password, salt)
        val created = now()
        val cv = ContentValues()
        cv.put("id", id)
        cv.put("email", email)
        cv.put("salt", salt)
        cv.put("hash", hash)
        cv.put("created", created)
        val rowId = writableDatabase.insert("users", null, cv)
        if (rowId < 0) return null
        val o = JSONObject()
        o.put("id", id)
        o.put("email", email)
        o.put("created", created)
        o.put("disabled", 0)
        return o
    }

    private fun userFromCursor(c: android.database.Cursor): JSONObject {
        val o = JSONObject()
        o.put("id", c.getString(0))
        o.put("email", c.getString(1))
        o.put("created", c.getLong(2))
        o.put("disabled", c.getInt(3))
        return o
    }

    fun userById(id: String): JSONObject? {
        val c = readableDatabase.rawQuery("SELECT id, email, created, disabled FROM users WHERE id=?", arrayOf(id))
        try {
            if (c.moveToFirst()) return userFromCursor(c)
        } finally {
            c.close()
        }
        return null
    }

    /** Mengembalikan data user bila email dan password cocok dan akun aktif, selain itu null. */
    fun verifyUser(email: String, password: String): JSONObject? {
        val c = readableDatabase.rawQuery(
            "SELECT id, email, created, disabled, salt, hash FROM users WHERE email=?",
            arrayOf(email)
        )
        try {
            if (c.moveToFirst()) {
                val salt = c.getString(4)
                val hash = c.getString(5)
                val disabled = c.getInt(3)
                if (Util.safeEquals(Util.hashPassword(password, salt), hash) && disabled == 0) {
                    return userFromCursor(c)
                }
            }
        } finally {
            c.close()
        }
        return null
    }

    fun listUsers(): JSONArray {
        val arr = JSONArray()
        val c = readableDatabase.rawQuery(
            "SELECT id, email, created, disabled FROM users ORDER BY created DESC",
            null
        )
        try {
            while (c.moveToNext()) arr.put(userFromCursor(c))
        } finally {
            c.close()
        }
        return arr
    }

    fun deleteUser(id: String): Boolean {
        val n = writableDatabase.delete("users", "id=?", arrayOf(id))
        writableDatabase.delete("sessions", "user_id=?", arrayOf(id))
        return n > 0
    }

    fun setUserDisabled(id: String, disabled: Boolean): Boolean {
        val cv = ContentValues()
        cv.put("disabled", if (disabled) 1 else 0)
        val n = writableDatabase.update("users", cv, "id=?", arrayOf(id))
        if (disabled) writableDatabase.delete("sessions", "user_id=?", arrayOf(id))
        return n > 0
    }

    fun setUserPassword(id: String, password: String): Boolean {
        val salt = Util.randomToken()
        val cv = ContentValues()
        cv.put("salt", salt)
        cv.put("hash", Util.hashPassword(password, salt))
        val n = writableDatabase.update("users", cv, "id=?", arrayOf(id))
        writableDatabase.delete("sessions", "user_id=?", arrayOf(id))
        return n > 0
    }

    // ------------------------------------------------------------ sesi

    fun createSession(userId: String, admin: Boolean): String {
        val token = Util.randomToken()
        val ttl = if (admin) 12L * 3600L * 1000L else 30L * 24L * 3600L * 1000L
        val cv = ContentValues()
        cv.put("token", token)
        cv.put("user_id", userId)
        cv.put("expires", now() + ttl)
        writableDatabase.insert("sessions", null, cv)
        writableDatabase.delete("sessions", "expires<?", arrayOf(now().toString()))
        return token
    }

    fun deleteSession(token: String) {
        writableDatabase.delete("sessions", "token=?", arrayOf(token))
    }

    fun principalForToken(token: String): Principal? {
        val c = readableDatabase.rawQuery(
            "SELECT user_id FROM sessions WHERE token=? AND expires>?",
            arrayOf(token, now().toString())
        )
        var uid: String? = null
        try {
            if (c.moveToFirst()) uid = c.getString(0)
        } finally {
            c.close()
        }
        val userId = uid ?: return null
        if (userId == "__admin__") return Principal("admin", null, "admin")
        val u = userById(userId) ?: return null
        if (u.optInt("disabled", 0) == 1) return null
        return Principal("user", u.getString("id"), u.getString("email"))
    }

    // ------------------------------------------------------------ dokumen

    fun cleanData(src: JSONObject): JSONObject {
        val out = JSONObject()
        val iter = src.keys()
        while (iter.hasNext()) {
            val k = iter.next()
            if (k == "id" || k.startsWith("_")) continue
            out.put(k, src.get(k))
        }
        return out
    }

    private fun docToJson(id: String, data: String, owner: String?, created: Long, updated: Long): JSONObject {
        val o = try {
            JSONObject(data)
        } catch (e: Exception) {
            JSONObject()
        }
        o.put("id", id)
        o.put("_owner", owner ?: JSONObject.NULL)
        o.put("_created", created)
        o.put("_updated", updated)
        return o
    }

    fun docGet(col: String, id: String): JSONObject? {
        val c = readableDatabase.rawQuery(
            "SELECT id, data, owner, created, updated FROM docs WHERE col=? AND id=?",
            arrayOf(col, id)
        )
        try {
            if (c.moveToFirst()) {
                return docToJson(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4))
            }
        } finally {
            c.close()
        }
        return null
    }

    /** Menyimpan dokumen. Hasil: (dokumen, true bila baru dibuat). */
    fun docSet(col: String, id: String, data: JSONObject, merge: Boolean, owner: String?): Pair<JSONObject, Boolean> {
        val wdb = writableDatabase
        val ts = now()
        val clean = cleanData(data)

        var existing = false
        var oldData = ""
        var oldOwner: String? = null
        var createdAt = ts
        val c = wdb.rawQuery("SELECT data, owner, created FROM docs WHERE col=? AND id=?", arrayOf(col, id))
        try {
            if (c.moveToFirst()) {
                existing = true
                oldData = c.getString(0)
                oldOwner = c.getString(1)
                createdAt = c.getLong(2)
            }
        } finally {
            c.close()
        }

        var finalData = clean
        if (existing && merge) {
            val base = try {
                JSONObject(oldData)
            } catch (e: Exception) {
                JSONObject()
            }
            val iter = clean.keys()
            while (iter.hasNext()) {
                val k = iter.next()
                base.put(k, clean.get(k))
            }
            finalData = base
        }
        val text = finalData.toString()
        if (text.length > 1024 * 1024) throw ApiException(400, "dokumen terlalu besar (maks 1 MB)")

        val ownerFinal: String? = if (existing) oldOwner else owner
        val cv = ContentValues()
        cv.put("data", text)
        cv.put("owner", ownerFinal)
        cv.put("updated", ts)
        if (existing) {
            wdb.update("docs", cv, "col=? AND id=?", arrayOf(col, id))
        } else {
            cv.put("col", col)
            cv.put("id", id)
            cv.put("created", ts)
            wdb.insert("docs", null, cv)
        }
        return Pair(docToJson(id, text, ownerFinal, createdAt, ts), !existing)
    }

    fun docDelete(col: String, id: String): Boolean {
        return writableDatabase.delete("docs", "col=? AND id=?", arrayOf(col, id)) > 0
    }

    fun docListRaw(col: String): ArrayList<JSONObject> {
        val out = ArrayList<JSONObject>()
        val c = readableDatabase.rawQuery(
            "SELECT id, data, owner, created, updated FROM docs WHERE col=? ORDER BY created DESC",
            arrayOf(col)
        )
        try {
            while (c.moveToNext()) {
                out.add(docToJson(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getLong(4)))
            }
        } finally {
            c.close()
        }
        return out
    }

    /** Menghapus semua dokumen koleksi beserta seluruh sub-koleksinya. */
    fun deleteCollection(col: String): Int {
        var total = writableDatabase.delete("docs", "col=?", arrayOf(col))
        val prefix = col + "/"
        val subs = ArrayList<String>()
        val c = readableDatabase.rawQuery(
            "SELECT DISTINCT col FROM docs WHERE col LIKE ? ESCAPE '\\'",
            arrayOf(likeEscape(prefix) + "%")
        )
        try {
            while (c.moveToNext()) {
                val full = c.getString(0)
                if (full.startsWith(prefix)) subs.add(full)
            }
        } finally {
            c.close()
        }
        for (full in subs) total += writableDatabase.delete("docs", "col=?", arrayOf(full))
        return total
    }

    private fun likeEscape(s: String): String {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    }

    /** Daftar koleksi tingkat atas beserta jumlah dokumen langsungnya. */
    fun collections(): JSONArray {
        val counts = java.util.TreeMap<String, Long>()
        val c = readableDatabase.rawQuery("SELECT col, COUNT(*) FROM docs GROUP BY col", null)
        try {
            while (c.moveToNext()) {
                val full = c.getString(0)
                val top = full.substringBefore('/')
                val n = if (full == top) c.getLong(1) else 0L
                counts[top] = (counts[top] ?: 0L) + n
            }
        } finally {
            c.close()
        }
        val arr = JSONArray()
        for ((name, n) in counts) {
            val r = rule(name)
            val o = JSONObject()
            o.put("name", name)
            o.put("count", n)
            o.put("read", r.first)
            o.put("write", r.second)
            arr.put(o)
        }
        return arr
    }

    /** Nama sub-koleksi langsung di bawah sebuah dokumen, mis. parent = "users/abc". */
    fun subcollections(parent: String): JSONArray {
        val prefix = parent + "/"
        val names = java.util.TreeSet<String>()
        val c = readableDatabase.rawQuery(
            "SELECT DISTINCT col FROM docs WHERE col LIKE ? ESCAPE '\\'",
            arrayOf(likeEscape(prefix) + "%")
        )
        try {
            while (c.moveToNext()) {
                val full = c.getString(0)
                if (full.startsWith(prefix)) names.add(full.substring(prefix.length).substringBefore('/'))
            }
        } finally {
            c.close()
        }
        val arr = JSONArray()
        for (n in names) arr.put(n)
        return arr
    }

    // ------------------------------------------------------------ aturan akses

    private fun ruleRow(key: String): Pair<String, String>? {
        val c = readableDatabase.rawQuery("SELECT can_read, can_write FROM rules WHERE col=?", arrayOf(key))
        try {
            if (c.moveToFirst()) return Pair(c.getString(0), c.getString(1))
        } finally {
            c.close()
        }
        return null
    }

    /** Aturan untuk sebuah target; bila tidak ada dipakai aturan bawaan "*", lalu login-saja. */
    fun rule(key: String): Pair<String, String> {
        val own = ruleRow(key)
        if (own != null) return own
        val def = ruleRow("*")
        if (def != null) return def
        return Pair("auth", "auth")
    }

    fun ruleSet(key: String, read: String, write: String) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO rules (col, can_read, can_write) VALUES (?, ?, ?)",
            arrayOf<Any>(key, read, write)
        )
    }

    fun ruleDelete(key: String) {
        writableDatabase.delete("rules", "col=?", arrayOf(key))
    }

    fun ruleList(): JSONArray {
        val arr = JSONArray()
        val c = readableDatabase.rawQuery("SELECT col, can_read, can_write FROM rules ORDER BY col", null)
        try {
            while (c.moveToNext()) {
                val o = JSONObject()
                o.put("key", c.getString(0))
                o.put("read", c.getString(1))
                o.put("write", c.getString(2))
                arr.put(o)
            }
        } finally {
            c.close()
        }
        return arr
    }

    // ------------------------------------------------------------ teks aturan & riwayat versi

    fun ruleItems(): List<Triple<String, String, String>> {
        val out = ArrayList<Triple<String, String, String>>()
        val c = readableDatabase.rawQuery("SELECT col, can_read, can_write FROM rules ORDER BY col", null)
        try {
            while (c.moveToNext()) out.add(Triple(c.getString(0), c.getString(1), c.getString(2)))
        } finally {
            c.close()
        }
        return out
    }

    /** Menyimpan aturan hasil kompilasi teks dan mencatat versi baru. Mengembalikan nomor versi. */
    fun rulesApply(items: List<Triple<String, String, String>>, body: String): Long {
        val db = writableDatabase
        var version = 0L
        db.beginTransaction()
        try {
            db.delete("rules", null, null)
            for (r in items) {
                db.execSQL(
                    "INSERT OR REPLACE INTO rules (col, can_read, can_write) VALUES (?, ?, ?)",
                    arrayOf<Any>(r.first, r.second, r.third)
                )
            }
            val cv = ContentValues()
            cv.put("body", body)
            cv.put("created", now())
            version = db.insert("rules_history", null, cv)
            db.execSQL("DELETE FROM rules_history WHERE version <= ?", arrayOf<Any>(version - 200L))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return version
    }

    /** Teks aturan yang berlaku: versi terbaru, atau dibuat dari tabel aturan bila belum pernah dipublikasikan. */
    fun rulesCurrent(): JSONObject {
        val o = JSONObject()
        val c = readableDatabase.rawQuery(
            "SELECT version, body, created FROM rules_history ORDER BY version DESC LIMIT 1",
            null
        )
        try {
            if (c.moveToFirst()) {
                o.put("version", c.getLong(0))
                o.put("text", c.getString(1))
                o.put("created", c.getLong(2))
                return o
            }
        } finally {
            c.close()
        }
        o.put("version", JSONObject.NULL)
        o.put("text", RulesText.generate(ruleItems()))
        o.put("created", JSONObject.NULL)
        return o
    }

    fun rulesHistory(): JSONArray {
        val arr = JSONArray()
        val c = readableDatabase.rawQuery(
            "SELECT version, created FROM rules_history ORDER BY version DESC LIMIT 100",
            null
        )
        try {
            while (c.moveToNext()) {
                val o = JSONObject()
                o.put("version", c.getLong(0))
                o.put("created", c.getLong(1))
                arr.put(o)
            }
        } finally {
            c.close()
        }
        return arr
    }

    fun rulesVersion(version: Long): JSONObject? {
        val c = readableDatabase.rawQuery(
            "SELECT version, body, created FROM rules_history WHERE version=?",
            arrayOf(version.toString())
        )
        try {
            if (c.moveToFirst()) {
                val o = JSONObject()
                o.put("version", c.getLong(0))
                o.put("text", c.getString(1))
                o.put("created", c.getLong(2))
                return o
            }
        } finally {
            c.close()
        }
        return null
    }

    // ------------------------------------------------------------ file

    fun fileInsert(id: String, name: String, mime: String, size: Long, owner: String?) {
        val cv = ContentValues()
        cv.put("id", id)
        cv.put("name", name)
        cv.put("mime", mime)
        cv.put("size", size)
        cv.put("owner", owner)
        cv.put("created", now())
        writableDatabase.insert("files", null, cv)
    }

    private fun fileFromCursor(c: android.database.Cursor): JSONObject {
        val o = JSONObject()
        o.put("id", c.getString(0))
        o.put("name", c.getString(1))
        o.put("mime", c.getString(2))
        o.put("size", c.getLong(3))
        o.put("owner", c.getString(4) ?: JSONObject.NULL)
        o.put("created", c.getLong(5))
        return o
    }

    fun fileGet(id: String): JSONObject? {
        val c = readableDatabase.rawQuery(
            "SELECT id, name, mime, size, owner, created FROM files WHERE id=?",
            arrayOf(id)
        )
        try {
            if (c.moveToFirst()) return fileFromCursor(c)
        } finally {
            c.close()
        }
        return null
    }

    /** owner null = semua file (admin). */
    fun fileList(owner: String?): JSONArray {
        val arr = JSONArray()
        val c = if (owner == null) {
            readableDatabase.rawQuery(
                "SELECT id, name, mime, size, owner, created FROM files ORDER BY created DESC",
                null
            )
        } else {
            readableDatabase.rawQuery(
                "SELECT id, name, mime, size, owner, created FROM files WHERE owner=? ORDER BY created DESC",
                arrayOf(owner)
            )
        }
        try {
            while (c.moveToNext()) arr.put(fileFromCursor(c))
        } finally {
            c.close()
        }
        return arr
    }

    fun fileDelete(id: String): Boolean {
        val n = writableDatabase.delete("files", "id=?", arrayOf(id))
        File(filesDir, id).delete()
        return n > 0
    }

    // ------------------------------------------------------------ statistik

    fun count(table: String): Long = DatabaseUtils.queryNumEntries(readableDatabase, table)

    fun filesBytes(): Long {
        return DatabaseUtils.longForQuery(readableDatabase, "SELECT COALESCE(SUM(size), 0) FROM files", null)
    }

    fun collectionCount(): Long {
        return DatabaseUtils.longForQuery(readableDatabase, "SELECT COUNT(DISTINCT col) FROM docs", null)
    }
}
