package com.phonebase.server

import org.json.JSONObject
import java.io.InputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Pusat pesan realtime: dokumen berubah dan channel pesan (SSE). */
object Hub {

    class Sub(val col: String?, val channel: String?) {
        val queue = LinkedBlockingQueue<String>(500)

        @Volatile
        var closed: Boolean = false
    }

    private val subs = CopyOnWriteArrayList<Sub>()

    fun add(s: Sub) {
        subs.add(s)
    }

    fun remove(s: Sub) {
        s.closed = true
        subs.remove(s)
    }

    fun count(): Int = subs.size

    fun closeAll() {
        for (s in subs) {
            s.closed = true
        }
        subs.clear()
    }

    fun publishDoc(type: String, col: String, id: String, doc: JSONObject?) {
        val ev = JSONObject()
        ev.put("type", type)
        ev.put("col", col)
        ev.put("id", id)
        ev.put("data", doc ?: JSONObject.NULL)
        ev.put("ts", System.currentTimeMillis())
        val text = "event: doc\ndata: " + ev.toString() + "\n\n"
        for (s in subs) {
            val c = s.col
            if (c != null && (c == col || c == "*")) {
                s.queue.offer(text)
            }
        }
    }

    fun publishChannel(channel: String, message: Any?, from: String?): Int {
        val ev = JSONObject()
        ev.put("channel", channel)
        ev.put("message", message ?: JSONObject.NULL)
        ev.put("from", from ?: JSONObject.NULL)
        ev.put("ts", System.currentTimeMillis())
        val text = "event: msg\ndata: " + ev.toString() + "\n\n"
        var n = 0
        for (s in subs) {
            if (s.channel != null && s.channel == channel) {
                s.queue.offer(text)
                n++
            }
        }
        return n
    }
}

/** Aliran SSE yang dibaca NanoHTTPD (chunked). Mengirim ping tiap 15 detik. */
class SseStream(private val sub: Hub.Sub) : InputStream() {
    private var cur: ByteArray = ByteArray(0)
    private var pos = 0

    init {
        sub.queue.offer("retry: 3000\n\n: connected\n\n")
    }

    private fun fill(): Boolean {
        while (pos >= cur.size) {
            if (sub.closed) return false
            val m: String? = try {
                sub.queue.poll(15, TimeUnit.SECONDS)
            } catch (e: InterruptedException) {
                return false
            }
            val text: String = m ?: ": ping\n\n"
            cur = text.toByteArray(Charsets.UTF_8)
            pos = 0
        }
        return true
    }

    override fun read(): Int {
        if (!fill()) return -1
        val v = cur[pos].toInt() and 0xff
        pos++
        return v
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (!fill()) return -1
        val n = Math.min(len, cur.size - pos)
        System.arraycopy(cur, pos, b, off, n)
        pos += n
        return n
    }

    override fun close() {
        Hub.remove(sub)
    }
}
