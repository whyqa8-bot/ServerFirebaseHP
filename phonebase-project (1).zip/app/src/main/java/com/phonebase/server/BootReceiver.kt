package com.phonebase.server

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menyalakan server otomatis setelah HP restart (bila opsi diaktifkan). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences("pb", Context.MODE_PRIVATE)
            if (prefs.getBoolean("autostart", false)) {
                try {
                    ServerService.start(context)
                } catch (e: Exception) {
                    // abaikan
                }
            }
        }
    }
}
