package com.phonebase.server

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicLong

/** Server HTTP: REST database, auth, file, realtime (SSE), dan dashboard web. */
class PhoneServer(
    private val context: Context,
    port: Int,
    private val store: Store
) : NanoHTTPD(port) {

    private val startedAt = System.currentTimeMillis()
    private val requests = AtomicLong(0)

    private val colRegex = Regex("^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
    private val idRegex = Regex("^[A-Za-z0-9][A-Za-z0-9_.:@-]{0,127}$")
    private val keyRegex = Regex("^[A-Za-z0-9_.:-]{1,70}$")

    private val maxFileBytes = 200L * 1024L * 1024L

    // ================================================================ entry

    override fun serve(session: IHTTPSession): Response {
        requests.incrementAndGet()
        return try {
            addCors(route(session))
        } catch (e: ApiException) {
            addCors(jsonResp(e.code, JSONObject().put("error", e.message ?: "error")))
        } catch (e: Exception) {
            val msg = e.message ?: e.javaClass.simpleName
            addCors(jsonResp(500, JSONObject().put("error", "kesalahan server: $msg")))
        }
    }

    private fun addCors(r: Response): Response {
        r.addHeader("Access-Control-Allow-Origin", "*")
        r.addHeader("Access-Control-Allow-Headers", "Authorization, Content-Type, X-File-Name")
        r.addHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        return r
    }

    private fun statusOf(code: Int): Status {
        return when (code) {
            200 -> Status.OK
            201 -> Status.CREATED
            204 -> Status.NO_CONTENT
            400 -> Status.BAD_REQUEST
            401 -> Status.UNAUTHORIZED
            403 -> Status.FORBIDDEN
            404 -> Status.NOT_FOUND
            405 -> Status.METHOD_NOT_ALLOWED
            409 -> Status.CONFLICT
            else -> Status.INTERNAL_ERROR
        }
    }

    private fun jsonResp(code: Int, body: Any): Response {
        return NanoHTTPD.newFixedLengthResponse(statusOf(code), "application/json; charset=utf-8", body.toString())
    }

    private fun asset(path: String, mime: String): Response {
        val text = try {
            context.assets.open(path).use { it.readBytes() }.toString(Charsets.UTF_8)
        } catch (e: Exception) {
            throw ApiException(404, "file tidak ditemukan")
        }
        val r = NanoHTTPD.newFixedLengthResponse(Status.OK, mime, text)
        r.addHeader("Cache-Control", "no-cache")
        return r
    }

    // ================================================================ helper

    private fun denied(p: Principal): ApiException {
        return ApiException(if (p.isAuthed) 403 else 401, "akses ditolak")
    }

    private fun clientIp(session: IHTTPSession): String {
        val cf = session.headers["cf-connecting-ip"]
        if (cf != null && cf.isNotEmpty()) return cf.trim()
        val xff = session.headers["x-forwarded-for"]
        if (xff != null && xff.isNotEmpty()) return xff.split(",")[0].trim()
        return session.remoteIpAddress ?: "unknown"
    }

    private fun principal(session: IHTTPSession): Principal {
        var token: String? = null
        val auth = session.headers["authorization"]
        if (auth != null && auth.startsWith("Bearer ", true)) token = auth.substring(7).trim()
        if (token == null) token = session.parameters["token"]?.firstOrNull()
        val t = token
        if (t == null || t.isEmpty()) return Principal("anon", null, null)
        return store.principalForToken(t) ?: Principal("anon", null, null)
    }

    private fun tokenOf(session: IHTTPSession): String? {
        val auth = session.headers["authorization"]
        if (auth != null && auth.startsWith("Bearer ", true)) return auth.substring(7).trim()
        return session.parameters["token"]?.firstOrNull()
    }

    private fun bodyBytes(session: IHTTPSession, max: Int): ByteArray {
        val len = (session.headers["content-length"] ?: "0").trim().toIntOrNull() ?: 0
        if (len < 0 || len > max) throw ApiException(400, "isi request terlalu besar")
        val buf = ByteArray(len)
        var off = 0
        val ins = session.inputStream
        while (off < len) {
            val n = ins.read(buf, off, len - off)
            if (n < 0) break
            off += n
        }
        return buf
    }

    private fun bodyJson(session: IHTTPSession): JSONObject {
        val b = bodyBytes(session, 2 * 1024 * 1024)
        if (b.isEmpty()) return JSONObject()
        return try {
            JSONObject(String(b, Charsets.UTF_8))
        } catch (e: Exception) {
            throw ApiException(400, "JSON tidak valid")
        }
    }

    private fun checkCol(col: String) {
        if (!colRegex.matches(col)) {
            throw ApiException(400, "nama koleksi tidak valid (huruf/angka/_/-/. maks 64, harus diawali huruf atau angka)")
        }
    }

    private fun checkId(id: String) {
        if (!idRegex.matches(id)) throw ApiException(400, "id dokumen tidak valid")
    }

    /** Path bersarang: koleksi/dokumen/sub-koleksi/dokumen/... (posisi genap = koleksi, ganjil = dokumen). */
    private fun checkPathParts(parts: List<String>) {
        if (parts.isEmpty() || parts.size > 12) throw ApiException(400, "path tidak valid")
        for (i in parts.indices) {
            if (i % 2 == 0) checkCol(parts[i]) else checkId(parts[i])
        }
    }

    private fun splitPath(raw: String): List<String> {
        return raw.split("/").filter { it.isNotEmpty() }
    }

    private fun requireAdmin(p: Principal) {
        if (!p.isAdmin) throw ApiException(if (p.isAuthed) 403 else 401, "khusus admin")
    }

    private fun canRead(key: String, p: Principal): Boolean {
        if (p.isAdmin) return true
        val rule = store.rule(key).first
        return when (rule) {
            "public" -> true
            "auth" -> p.isAuthed
            else -> false
        }
    }

    private fun canWrite(key: String, p: Principal, existing: JSONObject?): Boolean {
        if (p.isAdmin) return true
        val rule = store.rule(key).second
        return when (rule) {
            "public" -> true
            "auth" -> p.isAuthed
            "owner" -> {
                if (!p.isAuthed) {
                    false
                } else if (existing == null) {
                    true
                } else {
                    existing.optString("_owner", "") == (p.userId ?: "-")
                }
            }
            else -> false
        }
    }

    // ================================================================ routing

    private fun route(session: IHTTPSession): Response {
        val method = session.method.name
        if (method == "OPTIONS") {
            return NanoHTTPD.newFixedLengthResponse(Status.NO_CONTENT, "text/plain", "")
        }
        val seg = session.uri.split("/").filter { it.isNotEmpty() }

        if (seg.isEmpty() || (seg.size == 1 && seg[0] == "admin")) {
            return asset("web/index.html", "text/html; charset=utf-8")
        }
        if (seg.size == 1 && seg[0] == "app.js") return asset("web/app.js", "application/javascript; charset=utf-8")
        if (seg.size == 1 && seg[0] == "phonebase.js") {
            return asset("web/phonebase.js", "application/javascript; charset=utf-8")
        }
        if (seg[0] != "api" || seg.size < 2) throw ApiException(404, "tidak ditemukan")

        val p = principal(session)
        return when (seg[1]) {
            "health" -> jsonResp(
                200,
                JSONObject().put("ok", true).put("name", "PhoneBase").put("time", System.currentTimeMillis())
            )
            "auth" -> handleAuth(method, seg, session, p)
            "admin" -> handleAdmin(method, seg, session, p)
            "db" -> handleDb(method, seg, session, p)
            "realtime" -> handleRealtime(session, p)
            "channels" -> handleChannels(method, seg, session, p)
            "files" -> handleFiles(method, seg, session, p)
            else -> throw ApiException(404, "tidak ditemukan")
        }
    }

    // ================================================================ auth

    private fun handleAuth(method: String, seg: List<String>, session: IHTTPSession, p: Principal): Response {
        val action = if (seg.size > 2) seg[2] else ""

        if (method == "POST" && action == "register") {
            val b = bodyJson(session)
            val email = b.optString("email", "").trim().lowercase()
            val pw = b.optString("password", "")
            if (!email.contains("@") || email.length < 5 || email.length > 120) {
                throw ApiException(400, "email tidak valid")
            }
            if (pw.length < 6) throw ApiException(400, "password minimal 6 karakter")
            if (store.settingGet("allow_register", "1") != "1") throw ApiException(403, "pendaftaran ditutup")
            val ipKey = "reg:" + clientIp(session)
            if (Limiter.blocked(ipKey)) throw ApiException(403, "terlalu banyak percobaan, coba lagi nanti")
            Limiter.fail(ipKey)
            val user = store.createUser(email, pw) ?: throw ApiException(409, "email sudah terdaftar")
            val token = store.createSession(user.getString("id"), false)
            return jsonResp(201, JSONObject().put("token", token).put("user", user))
        }

        if (method == "POST" && action == "login") {
            val b = bodyJson(session)
            val email = b.optString("email", "").trim().lowercase()
            val pw = b.optString("password", "")
            val ipKey = "login:" + clientIp(session)
            val mailKey = "login:" + email
            if (Limiter.blocked(ipKey) || Limiter.blocked(mailKey)) {
                throw ApiException(403, "terlalu banyak percobaan, coba lagi 10 menit lagi")
            }
            val user = store.verifyUser(email, pw)
            if (user == null) {
                Limiter.fail(ipKey)
                Limiter.fail(mailKey)
                throw ApiException(401, "email atau password salah")
            }
            Limiter.clear(mailKey)
            val token = store.createSession(user.getString("id"), false)
            return jsonResp(200, JSONObject().put("token", token).put("user", user))
        }

        if (method == "GET" && action == "me") {
            if (!p.isAuthed) throw ApiException(401, "belum login")
            val o = JSONObject()
            o.put("role", p.kind)
            o.put("id", p.userId ?: JSONObject.NULL)
            o.put("email", p.email ?: JSONObject.NULL)
            return jsonResp(200, o)
        }

        if (method == "POST" && action == "logout") {
            val t = tokenOf(session)
            if (t != null) store.deleteSession(t)
            return jsonResp(200, JSONObject().put("ok", true))
        }

        if (method == "POST" && action == "password") {
            if (!p.isAuthed || p.isAdmin || p.userId == null) throw ApiException(401, "login sebagai user dulu")
            val b = bodyJson(session)
            val oldPw = b.optString("old", "")
            val newPw = b.optString("new", "")
            if (newPw.length < 6) throw ApiException(400, "password baru minimal 6 karakter")
            val mail = p.email ?: ""
            val key = "login:" + mail
            if (Limiter.blocked(key)) throw ApiException(403, "terlalu banyak percobaan")
            if (store.verifyUser(mail, oldPw) == null) {
                Limiter.fail(key)
                throw ApiException(401, "password lama salah")
            }
            store.setUserPassword(p.userId, newPw)
            val token = store.createSession(p.userId, false)
            return jsonResp(200, JSONObject().put("token", token))
        }

        throw ApiException(404, "tidak ditemukan")
    }

    // ================================================================ admin

    private fun handleAdmin(method: String, seg: List<String>, session: IHTTPSession, p: Principal): Response {
        val action = if (seg.size > 2) seg[2] else ""

        if (method == "POST" && action == "login") {
            val b = bodyJson(session)
            val pw = b.optString("password", "")
            val ipKey = "admin:" + clientIp(session)
            if (Limiter.blocked(ipKey) || Limiter.blocked("admin:all")) {
                throw ApiException(403, "terlalu banyak percobaan, coba lagi 10 menit lagi")
            }
            if (!store.verifyAdmin(pw)) {
                Limiter.fail(ipKey)
                Limiter.fail("admin:all")
                throw ApiException(401, "password admin salah")
            }
            Limiter.clear(ipKey)
            val token = store.createSession("__admin__", true)
            return jsonResp(200, JSONObject().put("token", token))
        }

        requireAdmin(p)

        if (method == "GET" && action == "stats") {
            val o = JSONObject()
            o.put("users", store.count("users"))
            o.put("docs", store.count("docs"))
            o.put("collections", store.collectionCount())
            o.put("files", store.count("files"))
            o.put("fileBytes", store.filesBytes())
            o.put("connections", Hub.count())
            o.put("requests", requests.get())
            val dbFile = context.getDatabasePath("phonebase.db")
            o.put("dbBytes", dbFile.length() + File(dbFile.path + "-wal").length())
            o.put("uptimeMs", System.currentTimeMillis() - startedAt)
            o.put("allowRegister", store.settingGet("allow_register", "1") == "1")
            return jsonResp(200, o)
        }

        if (method == "GET" && action == "collections") {
            return jsonResp(200, JSONObject().put("items", store.collections()))
        }

        if (method == "GET" && action == "subcollections") {
            val parts = splitPath(session.parameters["path"]?.firstOrNull() ?: "")
            checkPathParts(parts)
            if (parts.size % 2 != 0) throw ApiException(400, "path harus menunjuk ke sebuah dokumen")
            return jsonResp(200, JSONObject().put("items", store.subcollections(parts.joinToString("/"))))
        }

        if (method == "DELETE" && action == "collections") {
            val raw = session.parameters["path"]?.firstOrNull() ?: (if (seg.size == 4) seg[3] else "")
            val parts = splitPath(raw)
            checkPathParts(parts)
            if (parts.size % 2 == 0) throw ApiException(400, "path harus menunjuk ke sebuah koleksi")
            val n = store.deleteCollection(parts.joinToString("/"))
            return jsonResp(200, JSONObject().put("deleted", n))
        }

        if (action == "users") {
            if (method == "GET" && seg.size == 3) {
                return jsonResp(200, JSONObject().put("items", store.listUsers()))
            }
            if (method == "POST" && seg.size == 3) {
                val b = bodyJson(session)
                val email = b.optString("email", "").trim().lowercase()
                val pw = b.optString("password", "")
                if (!email.contains("@") || email.length < 5) throw ApiException(400, "email tidak valid")
                if (pw.length < 6) throw ApiException(400, "password minimal 6 karakter")
                val u = store.createUser(email, pw) ?: throw ApiException(409, "email sudah terdaftar")
                return jsonResp(201, u)
            }
            if (seg.size == 4) {
                val id = seg[3]
                if (method == "DELETE") {
                    if (!store.deleteUser(id)) throw ApiException(404, "user tidak ada")
                    return jsonResp(200, JSONObject().put("ok", true))
                }
                if (method == "PUT") {
                    val b = bodyJson(session)
                    if (b.has("disabled")) store.setUserDisabled(id, b.optBoolean("disabled", false))
                    val pw = b.optString("password", "")
                    if (pw.isNotEmpty()) {
                        if (pw.length < 6) throw ApiException(400, "password minimal 6 karakter")
                        store.setUserPassword(id, pw)
                    }
                    return jsonResp(200, JSONObject().put("ok", true))
                }
            }
        }

        if (action == "rules") {
            if (method == "GET" && seg.size == 3) {
                return jsonResp(200, JSONObject().put("items", store.ruleList()))
            }
            if (method == "GET" && seg.size == 4 && seg[3] == "current") {
                return jsonResp(200, store.rulesCurrent())
            }
            if (method == "GET" && seg.size == 4 && seg[3] == "history") {
                return jsonResp(200, JSONObject().put("items", store.rulesHistory()))
            }
            if (method == "GET" && seg.size == 5 && seg[3] == "history") {
                val v = seg[4].toLongOrNull() ?: throw ApiException(400, "versi tidak valid")
                val o = store.rulesVersion(v) ?: throw ApiException(404, "versi tidak ditemukan")
                return jsonResp(200, o)
            }
            if (method == "PUT" && seg.size == 3) {
                val b = bodyJson(session)
                val text = b.optString("text", "")
                val items = RulesText.parse(text)
                val v = store.rulesApply(items, text)
                return jsonResp(200, JSONObject().put("ok", true).put("version", v))
            }
            if (method == "POST" && seg.size == 4 && seg[3] == "test") {
                val b = bodyJson(session)
                val items = RulesText.parse(b.optString("text", ""))
                val parts = splitPath(b.optString("path", ""))
                checkPathParts(parts)
                val op = if (b.optString("op", "read") == "write") "write" else "read"
                val who = b.optString("who", "anon")
                val res = RulesText.evaluate(items, parts.joinToString("/"), op, who)
                return jsonResp(200, JSONObject().put("allowed", res.first).put("rule", res.second))
            }
        }

        if (method == "PUT" && action == "settings") {
            val b = bodyJson(session)
            if (b.has("allowRegister")) {
                store.settingSet("allow_register", if (b.optBoolean("allowRegister", true)) "1" else "0")
            }
            return jsonResp(200, JSONObject().put("ok", true))
        }

        if (method == "POST" && action == "password") {
            val b = bodyJson(session)
            val pw = b.optString("password", "")
            if (pw.length < 8) throw ApiException(400, "password admin minimal 8 karakter")
            store.setAdminPassword(pw)
            return jsonResp(200, JSONObject().put("ok", true))
        }

        throw ApiException(404, "tidak ditemukan")
    }

    // ================================================================ database

    private fun cmp(a: Any?, b: String): Int {
        if (a is Number) {
            val bn = b.toDoubleOrNull()
            if (bn != null) return a.toDouble().compareTo(bn)
        }
        return a.toString().compareTo(b)
    }

    private fun matches(doc: JSONObject, field: String, op: String, value: String): Boolean {
        if (!doc.has(field)) return op == "ne"
        val a = doc.opt(field)
        return when (op) {
            "eq" -> cmp(a, value) == 0
            "ne" -> cmp(a, value) != 0
            "gt" -> cmp(a, value) > 0
            "gte" -> cmp(a, value) >= 0
            "lt" -> cmp(a, value) < 0
            "lte" -> cmp(a, value) <= 0
            "contains" -> a.toString().contains(value, true)
            else -> throw ApiException(400, "operator tidak dikenal: $op (eq, ne, gt, gte, lt, lte, contains)")
        }
    }

    private fun sortDocs(list: MutableList<JSONObject>, order: String) {
        val desc = order.startsWith("-")
        val field = order.removePrefix("-")
        val comparator = Comparator<JSONObject> { x, y ->
            val a = x.opt(field)
            val b = y.opt(field)
            val r = if (a is Number && b is Number) {
                a.toDouble().compareTo(b.toDouble())
            } else {
                a.toString().compareTo(b.toString())
            }
            if (desc) -r else r
        }
        list.sortWith(comparator)
    }

    private fun listDocs(col: String, session: IHTTPSession): Response {
        val prm = session.parameters
        var items: MutableList<JSONObject> = store.docListRaw(col)
        val wheres = prm["where"]
        if (wheres != null) {
            for (w in wheres) {
                val parts = w.split(":", limit = 3)
                if (parts.size < 3) throw ApiException(400, "format where: field:operator:nilai")
                val f = parts[0]
                val o = parts[1]
                val v = parts[2]
                items = items.filter { matches(it, f, o, v) }.toMutableList()
            }
        }
        sortDocs(items, prm["order"]?.firstOrNull() ?: "-_created")
        val total = items.size
        val limit = (prm["limit"]?.firstOrNull()?.toIntOrNull() ?: 100).coerceIn(1, 1000)
        val offset = (prm["offset"]?.firstOrNull()?.toIntOrNull() ?: 0).coerceAtLeast(0)
        val arr = JSONArray()
        var i = offset
        while (i < total && i < offset + limit) {
            arr.put(items[i])
            i++
        }
        val o = JSONObject()
        o.put("items", arr)
        o.put("count", total)
        o.put("limit", limit)
        o.put("offset", offset)
        return jsonResp(200, o)
    }

    private fun handleDb(method: String, seg: List<String>, session: IHTTPSession, p: Principal): Response {
        val parts = seg.drop(2)
        if (parts.isEmpty()) throw ApiException(404, "nama koleksi wajib diisi")
        checkPathParts(parts)
        val isDoc = parts.size % 2 == 0
        val col = if (isDoc) parts.dropLast(1).joinToString("/") else parts.joinToString("/")
        val ruleKey = parts[0]

        if (!isDoc) {
            if (method == "GET") {
                if (!canRead(ruleKey, p)) throw denied(p)
                return listDocs(col, session)
            }
            if (method == "POST") {
                if (!canWrite(ruleKey, p, null)) throw denied(p)
                val body = bodyJson(session)
                val id = Util.randomId(20)
                val res = store.docSet(col, id, body, false, p.userId)
                Hub.publishDoc("created", col, id, res.first)
                return jsonResp(201, res.first)
            }
            throw ApiException(405, "method tidak didukung")
        }

        val id = parts.last()

        if (method == "GET") {
            if (!canRead(ruleKey, p)) throw denied(p)
            val doc = store.docGet(col, id) ?: throw ApiException(404, "dokumen tidak ditemukan")
            return jsonResp(200, doc)
        }
        if (method == "PUT" || method == "PATCH") {
            val existing = store.docGet(col, id)
            if (!canWrite(ruleKey, p, existing)) throw denied(p)
            val body = bodyJson(session)
            val merge = method == "PATCH" || session.parameters["merge"]?.firstOrNull() == "1"
            val res = store.docSet(col, id, body, merge, p.userId)
            Hub.publishDoc(if (res.second) "created" else "updated", col, id, res.first)
            return jsonResp(200, res.first)
        }
        if (method == "DELETE") {
            val existing = store.docGet(col, id) ?: throw ApiException(404, "dokumen tidak ditemukan")
            if (!canWrite(ruleKey, p, existing)) throw denied(p)
            store.docDelete(col, id)
            Hub.publishDoc("deleted", col, id, null)
            return jsonResp(200, JSONObject().put("ok", true))
        }
        throw ApiException(405, "method tidak didukung")
    }

    // ================================================================ realtime

    private fun handleRealtime(session: IHTTPSession, p: Principal): Response {
        val col = session.parameters["col"]?.firstOrNull()
        val ch = session.parameters["channel"]?.firstOrNull()
        val sub: Hub.Sub
        if (col != null) {
            if (col == "*") {
                requireAdmin(p)
                sub = Hub.Sub("*", null)
            } else {
                val parts = splitPath(col)
                checkPathParts(parts)
                if (parts.size % 2 == 0) throw ApiException(400, "col harus berupa koleksi, bukan dokumen")
                if (!canRead(parts[0], p)) throw denied(p)
                sub = Hub.Sub(parts.joinToString("/"), null)
            }
        } else if (ch != null) {
            checkCol(ch)
            if (!canRead("ch:$ch", p)) throw denied(p)
            sub = Hub.Sub(null, ch)
        } else {
            throw ApiException(400, "parameter col atau channel wajib diisi")
        }
        Hub.add(sub)
        val r = NanoHTTPD.newChunkedResponse(Status.OK, "text/event-stream; charset=utf-8", SseStream(sub))
        r.addHeader("Cache-Control", "no-cache")
        r.addHeader("X-Accel-Buffering", "no")
        return r
    }

    private fun handleChannels(method: String, seg: List<String>, session: IHTTPSession, p: Principal): Response {
        if (method == "POST" && seg.size == 4 && seg[3] == "publish") {
            val ch = seg[2]
            checkCol(ch)
            if (!canWrite("ch:$ch", p, null)) throw denied(p)
            val b = bodyJson(session)
            val n = Hub.publishChannel(ch, b.opt("message"), p.email)
            return jsonResp(200, JSONObject().put("ok", true).put("delivered", n))
        }
        throw ApiException(404, "tidak ditemukan")
    }

    // ================================================================ file

    private fun cleanName(raw: String): String {
        var n = raw.trim()
        n = n.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
        if (n.isEmpty()) n = "file"
        if (n.length > 120) n = n.substring(0, 120)
        return n
    }

    private fun handleFiles(method: String, seg: List<String>, session: IHTTPSession, p: Principal): Response {
        if (seg.size == 2) {
            if (method == "POST") {
                if (!canWrite("_files", p, null)) throw denied(p)
                val len = (session.headers["content-length"] ?: "0").trim().toLongOrNull() ?: 0L
                if (len <= 0L) throw ApiException(400, "isi file kosong")
                if (len > maxFileBytes) throw ApiException(400, "file terlalu besar (maks 200 MB)")
                val name = cleanName(session.parameters["name"]?.firstOrNull() ?: session.headers["x-file-name"] ?: "file")
                var mime = session.headers["content-type"] ?: "application/octet-stream"
                if (mime.isEmpty()) mime = "application/octet-stream"
                val id = Util.randomId(16)
                val f = File(store.filesDir, id)
                val ins = session.inputStream
                var remaining = len
                FileOutputStream(f).use { out ->
                    val buf = ByteArray(16384)
                    while (remaining > 0L) {
                        val want = Math.min(buf.size.toLong(), remaining).toInt()
                        val n = ins.read(buf, 0, want)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        remaining -= n.toLong()
                    }
                }
                if (remaining > 0L) {
                    f.delete()
                    throw ApiException(400, "upload terputus")
                }
                store.fileInsert(id, name, mime, len, p.userId)
                return jsonResp(201, store.fileGet(id) ?: JSONObject())
            }
            if (method == "GET") {
                if (!p.isAuthed) throw denied(p)
                val items = if (p.isAdmin) store.fileList(null) else store.fileList(p.userId)
                return jsonResp(200, JSONObject().put("items", items))
            }
            throw ApiException(405, "method tidak didukung")
        }

        if (seg.size == 3) {
            val id = seg[2]
            checkId(id)
            val meta = store.fileGet(id) ?: throw ApiException(404, "file tidak ditemukan")
            if (method == "GET") {
                val ownsIt = p.isAuthed && meta.optString("owner", "") == (p.userId ?: "-")
                if (!ownsIt && !canRead("_files", p)) throw denied(p)
                val f = File(store.filesDir, id)
                if (!f.exists()) throw ApiException(404, "file hilang dari penyimpanan")
                val r = NanoHTTPD.newFixedLengthResponse(
                    Status.OK,
                    meta.optString("mime", "application/octet-stream"),
                    FileInputStream(f),
                    f.length()
                )
                val safe = meta.optString("name", "file").replace("\"", "_")
                val disp = if (session.parameters["download"]?.firstOrNull() == "1") "attachment" else "inline"
                r.addHeader("Content-Disposition", "$disp; filename=\"$safe\"")
                r.addHeader("Cache-Control", "private, max-age=3600")
                return r
            }
            if (method == "DELETE") {
                val ownsIt = p.isAuthed && meta.optString("owner", "") == (p.userId ?: "-")
                if (!p.isAdmin && !ownsIt) throw denied(p)
                store.fileDelete(id)
                return jsonResp(200, JSONObject().put("ok", true))
            }
        }
        throw ApiException(404, "tidak ditemukan")
    }
}
