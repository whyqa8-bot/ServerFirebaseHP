package com.phonebase.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import fi.iki.elonen.NanoHTTPD

/** Service latar depan yang menjaga server tetap hidup. */
class ServerService : Service() {

    companion object {
        const val ACTION_START = "com.phonebase.server.START"
        private const val CHANNEL_ID = "phonebase_server"
        private const val NOTIF_ID = 1

        @Volatile
        var server: PhoneServer? = null

        @Volatile
        var lastError: String = ""

        fun isRunning(): Boolean = server != null

        fun port(ctx: Context): Int {
            return ctx.getSharedPreferences("pb", Context.MODE_PRIVATE).getInt("port", 8080)
        }

        fun start(ctx: Context) {
            val i = Intent(ctx, ServerService::class.java)
            i.action = ACTION_START
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ServerService::class.java))
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notif = buildNotification("Memulai server...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        startServer()

        if (server == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        updateNotification()
        return START_STICKY
    }

    override fun onDestroy() {
        stopServer()
        super.onDestroy()
    }

    private fun startServer() {
        if (server != null) return
        try {
            val store = Store.get(applicationContext)
            store.ensureAdmin()
            val s = PhoneServer(applicationContext, port(applicationContext), store)
            s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            server = s
            lastError = ""
            acquireLocks()
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            server = null
        }
    }

    private fun stopServer() {
        try {
            server?.stop()
        } catch (e: Exception) {
            // abaikan
        }
        server = null
        Hub.closeAll()
        releaseLocks()
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "phonebase:cpu")
            wl.setReferenceCounted(false)
            wl.acquire()
            wakeLock = wl

            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val fl = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "phonebase:wifi")
            fl.setReferenceCounted(false)
            fl.acquire()
            wifiLock = fl
        } catch (e: Exception) {
            // abaikan
        }
    }

    private fun releaseLocks() {
        try {
            val wl = wakeLock
            if (wl != null && wl.isHeld) wl.release()
            val fl = wifiLock
            if (fl != null && fl.isHeld) fl.release()
        } catch (e: Exception) {
            // abaikan
        }
        wakeLock = null
        wifiLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "PhoneBase Server", NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification {
        val open = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("PhoneBase berjalan")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification() {
        val ips = Util.localIps()
        val addr = if (ips.isEmpty()) "port " + port(this) else "http://" + ips[0] + ":" + port(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(addr))
    }
}
