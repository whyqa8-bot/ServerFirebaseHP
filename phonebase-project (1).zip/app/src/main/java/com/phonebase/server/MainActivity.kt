package com.phonebase.server

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Layar utama: nyalakan/matikan server, lihat alamat & password admin, buka dashboard. */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var urlView: TextView
    private lateinit var adminView: TextView
    private lateinit var portInput: EditText
    private lateinit var toggleBtn: Button
    private lateinit var remoteInput: EditText

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.get(this).ensureAdmin()
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(content: String, size: Float, bold: Boolean, color: String): TextView {
        val t = TextView(this)
        t.text = content
        t.textSize = size
        if (bold) t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Color.parseColor(color))
        return t
    }

    private fun add(parent: LinearLayout, v: View, topDp: Int) {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(topDp)
        parent.addView(v, lp)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun buildUi() {
        val prefs = getSharedPreferences("pb", Context.MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(32))

        add(root, text("PhoneBase", 28f, true, "#0F172A"), 0)
        add(root, text("Server database + auth + file + realtime di HP ini", 14f, false, "#64748B"), 2)

        statusView = text("", 18f, true, "#0F172A")
        add(root, statusView, 20)

        add(root, text("Alamat server", 13f, true, "#64748B"), 14)
        urlView = text("", 15f, false, "#0F172A")
        urlView.setTextIsSelectable(true)
        add(root, urlView, 2)

        add(root, text("Password admin dashboard", 13f, true, "#64748B"), 14)
        adminView = text("", 17f, true, "#0369A1")
        adminView.setTextIsSelectable(true)
        add(root, adminView, 2)

        add(root, text("Port", 13f, true, "#64748B"), 14)
        portInput = EditText(this)
        portInput.setText(prefs.getInt("port", 8080).toString())
        portInput.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        add(root, portInput, 2)

        toggleBtn = Button(this)
        toggleBtn.setOnClickListener {
            if (ServerService.isRunning()) {
                ServerService.stop(this)
                toast("Server dimatikan")
            } else {
                val port = portInput.text.toString().trim().toIntOrNull() ?: 0
                if (port < 1024 || port > 65535) {
                    toast("Port harus antara 1024 dan 65535")
                } else {
                    prefs.edit().putInt("port", port).apply()
                    ServerService.start(this)
                }
            }
            handler.postDelayed({ refresh() }, 600)
        }
        add(root, toggleBtn, 14)

        val auto = CheckBox(this)
        auto.text = "Nyalakan otomatis saat HP menyala"
        auto.isChecked = prefs.getBoolean("autostart", false)
        auto.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("autostart", checked).apply()
        }
        add(root, auto, 8)

        val batt = Button(this)
        batt.text = "Izinkan jalan terus di latar belakang"
        batt.setOnClickListener {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                toast("Sudah diizinkan")
            } else {
                try {
                    val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    i.data = Uri.parse("package:$packageName")
                    startActivity(i)
                } catch (e: Exception) {
                    toast("Buka Pengaturan > Baterai, lalu izinkan PhoneBase tanpa batasan")
                }
            }
        }
        add(root, batt, 4)

        val openLocal = Button(this)
        openLocal.text = "Buka dashboard (HP ini)"
        openLocal.setOnClickListener {
            if (!ServerService.isRunning()) {
                toast("Nyalakan server dulu")
            } else {
                openDashboard("http://127.0.0.1:" + ServerService.port(this) + "/")
            }
        }
        add(root, openLocal, 4)

        add(root, text("Kontrol server lain", 16f, true, "#0F172A"), 28)
        add(
            root,
            text("Masukkan alamat server PhoneBase di HP lain, lalu login sebagai admin.", 13f, false, "#64748B"),
            2
        )
        remoteInput = EditText(this)
        remoteInput.hint = "http://192.168.1.10:8080"
        remoteInput.setText(prefs.getString("remote", "") ?: "")
        remoteInput.inputType =
            android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        add(root, remoteInput, 6)

        val openRemote = Button(this)
        openRemote.text = "Buka dashboard server ini"
        openRemote.setOnClickListener {
            var u = remoteInput.text.toString().trim()
            if (u.isEmpty()) {
                toast("Isi alamat server dulu")
            } else {
                if (!u.startsWith("http://") && !u.startsWith("https://")) u = "http://$u"
                prefs.edit().putString("remote", u).apply()
                openDashboard(u)
            }
        }
        add(root, openRemote, 4)

        add(
            root,
            text(
                "Akses dari internet: pakai Tailscale (pribadi, aman) atau Cloudflare Tunnel (publik, HTTPS). " +
                    "Lihat README.",
                12f, false, "#64748B"
            ),
            28
        )

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun openDashboard(url: String) {
        val i = Intent(this, DashboardActivity::class.java)
        i.putExtra("url", url)
        startActivity(i)
    }

    private fun refresh() {
        val running = ServerService.isRunning()
        val port = ServerService.port(this)

        if (running) {
            statusView.text = "● Server BERJALAN"
            statusView.setTextColor(Color.parseColor("#15803D"))
            toggleBtn.text = "Matikan server"
        } else {
            val err = ServerService.lastError
            statusView.text = if (err.isEmpty()) "○ Server mati" else "○ Server mati\nGagal: $err"
            statusView.setTextColor(Color.parseColor("#B91C1C"))
            toggleBtn.text = "Nyalakan server"
        }

        if (running) {
            val sb = StringBuilder()
            for (ip in Util.localIps()) {
                sb.append("http://").append(ip).append(":").append(port).append("\n")
            }
            sb.append("http://127.0.0.1:").append(port).append("  (HP ini saja)")
            urlView.text = sb.toString()
        } else {
            urlView.text = "-"
        }

        val plain = Store.get(this).adminPasswordPlain()
        adminView.text = if (plain.isEmpty()) "(sudah kamu ganti di dashboard)" else plain
    }
}
