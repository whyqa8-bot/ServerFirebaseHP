package com.phonebase.server

/**
 * Aturan akses dalam bentuk teks ala Firestore Rules (versi sederhana).
 *
 *   rules_version = '1';
 *   service phonebase {
 *     match /{document=**} {            // aturan bawaan untuk semua koleksi
 *       allow read, write: if signedIn();
 *     }
 *     match /users/{doc} {
 *       allow read: if signedIn();
 *       allow write: if isOwner();
 *     }
 *   }
 *
 * Kondisi yang dikenal: true, false, signedIn(), isOwner() (hanya write), isAdmin().
 * Aturan sebuah koleksi berlaku juga untuk semua sub-koleksinya. Admin selalu boleh.
 */
object RulesText {

    private val blockRegex =
        Regex("""match\s+/(\{document=\*\*\}|[A-Za-z0-9_.:-]{1,70})(?:/\{[A-Za-z0-9_]+(?:=\*\*)?\})?\s*\{([^{}]*)\}""")
    private val allowRegex = Regex("""allow\s+([A-Za-z,\s]+?)\s*:\s*if\s+([^;]+?)\s*;""")
    private val commentRegex = Regex("//[^\n]*")
    private val matchWord = Regex("\\bmatch\\b")
    private val allowWord = Regex("\\ballow\\b")

    private fun level(expr: String, write: Boolean, key: String): String {
        val e = expr.replace(" ", "")
        return when (e) {
            "true" -> "public"
            "signedIn()" -> "auth"
            "isAdmin()", "false" -> "admin"
            "isOwner()" -> {
                if (!write) throw ApiException(400, "isOwner() hanya boleh untuk write (di /$key)")
                "owner"
            }
            else -> throw ApiException(
                400,
                "kondisi tidak dikenal: \"$expr\" (di /$key). Pakai: true, signedIn(), isOwner(), isAdmin(), false"
            )
        }
    }

    /** Mengubah teks aturan menjadi daftar (target, baca, tulis). Melempar ApiException bila salah. */
    fun parse(raw: String): List<Triple<String, String, String>> {
        val text = raw.replace(commentRegex, "")
        val open = text.count { it == '{' }
        val close = text.count { it == '}' }
        if (open != close) throw ApiException(400, "kurung kurawal { } tidak seimbang")

        val out = ArrayList<Triple<String, String, String>>()
        val seen = HashSet<String>()
        var blocks = 0
        for (m in blockRegex.findAll(text)) {
            blocks++
            var key = m.groupValues[1]
            if (key.startsWith("{")) key = "*"
            if (!seen.add(key)) throw ApiException(400, "aturan ganda untuk /$key")
            val body = m.groupValues[2]
            var read = "admin"
            var write = "admin"
            var allows = 0
            for (a in allowRegex.findAll(body)) {
                allows++
                val ops = a.groupValues[1].split(",").map { it.trim() }.filter { it.isNotEmpty() }
                val expr = a.groupValues[2].trim()
                if (ops.isEmpty()) throw ApiException(400, "allow tanpa operasi di /$key")
                for (op in ops) {
                    if (op == "read") {
                        read = level(expr, false, key)
                    } else if (op == "write") {
                        write = level(expr, true, key)
                    } else {
                        throw ApiException(400, "operasi \"$op\" tidak dikenal di /$key (pakai read atau write)")
                    }
                }
            }
            val declared = allowWord.findAll(body).count()
            if (declared != allows) {
                throw ApiException(400, "ada baris allow yang salah format di /$key. Contoh: allow read, write: if signedIn();")
            }
            out.add(Triple(key, read, write))
        }
        val declaredBlocks = matchWord.findAll(text).count()
        if (declaredBlocks != blocks) {
            throw ApiException(400, "ada blok match yang salah format. Contoh: match /users/{doc} { allow read: if signedIn(); }")
        }
        return out
    }

    private fun readExpr(level: String): String {
        return when (level) {
            "public" -> "true"
            "auth" -> "signedIn()"
            else -> "isAdmin()"
        }
    }

    private fun writeExpr(level: String): String {
        return when (level) {
            "public" -> "true"
            "auth" -> "signedIn()"
            "owner" -> "isOwner()"
            else -> "isAdmin()"
        }
    }

    private fun block(sb: StringBuilder, header: String, read: String, write: String) {
        sb.append("  match ").append(header).append(" {\n")
        sb.append("    allow read: if ").append(readExpr(read)).append(";\n")
        sb.append("    allow write: if ").append(writeExpr(write)).append(";\n")
        sb.append("  }\n\n")
    }

    /** Membuat teks aturan dari aturan yang tersimpan (dipakai sebelum ada versi yang dipublikasikan). */
    fun generate(items: List<Triple<String, String, String>>): String {
        val sb = StringBuilder()
        sb.append("rules_version = '1';\n")
        sb.append("service phonebase {\n")
        sb.append("  // Admin selalu boleh membaca dan menulis semuanya.\n")
        sb.append("  // Kondisi yang dikenal: true, false, signedIn(), isOwner() (hanya write), isAdmin().\n")
        sb.append("  // Aturan sebuah koleksi berlaku juga untuk sub-koleksinya.\n")
        sb.append("  // Target khusus: /_files/{doc} untuk file, /ch:nama/{doc} untuk channel pesan.\n\n")
        val def = items.firstOrNull { it.first == "*" }
        block(sb, "/{document=**}", def?.second ?: "auth", def?.third ?: "auth")
        for (r in items) {
            if (r.first == "*") continue
            block(sb, "/" + r.first + "/{doc}", r.second, r.third)
        }
        sb.append("}\n")
        return sb.toString()
    }

    private fun allowed(level: String, write: Boolean, who: String): Boolean {
        val ok = when (level) {
            "public" -> true
            "auth" -> who != "anon"
            "owner" -> write && who == "owner"
            else -> false
        }
        return ok || who == "admin"
    }

    /**
     * Simulasi: apakah [who] (anon, user, owner, admin) boleh [op] (read/write) pada [path]?
     * Mengembalikan (boleh, keterangan aturan yang dipakai).
     */
    fun evaluate(items: List<Triple<String, String, String>>, path: String, op: String, who: String): Pair<Boolean, String> {
        val key = path.trim('/').substringBefore('/')
        var hit = items.firstOrNull { it.first == key }
        var label = "match /$key"
        if (hit == null) {
            hit = items.firstOrNull { it.first == "*" }
            label = "match /{document=**} (bawaan)"
        }
        val read = hit?.second ?: "auth"
        val write = hit?.third ?: "auth"
        if (hit == null) label = "tidak ada aturan, dipakai bawaan (harus login)"
        val level = if (op == "write") write else read
        return Pair(allowed(level, op == "write", who), label)
    }
}
