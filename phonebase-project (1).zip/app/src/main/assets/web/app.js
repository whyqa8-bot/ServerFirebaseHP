(function () {
  'use strict';

  // ============================================================ util
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var enc = encodeURIComponent;
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var ORIGIN = location.origin;
  var token = '';
  try { token = localStorage.getItem('pb_admin') || ''; } catch (e) { /* abaikan */ }
  function saveToken(t) {
    token = t || '';
    try {
      if (token) localStorage.setItem('pb_admin', token); else localStorage.removeItem('pb_admin');
    } catch (e) { /* abaikan */ }
  }

  // state: seq = penanda render terbaru, lim/flt = batas & filter per koleksi
  var S = { view: 'home', tab: 'data', path: [], es: null, log: [], seq: 0, lim: {}, flt: {}, pending: false, live: null };

  var toastTimer = null;
  function toast(msg, bad) {
    var t = $('#toast');
    t.textContent = msg;
    t.style.background = bad ? 'var(--danger)' : 'var(--text)';
    t.style.color = bad ? '#fff' : 'var(--bg)';
    t.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.style.display = 'none'; }, 3400);
  }

  async function api(method, path, body) {
    var opt = { method: method, headers: {} };
    if (token) opt.headers['Authorization'] = 'Bearer ' + token;
    if (body !== undefined) {
      opt.headers['Content-Type'] = 'application/json';
      opt.body = JSON.stringify(body);
    }
    var r = await fetch(path, opt);
    var data = null;
    try { data = await r.json(); } catch (e) { /* bukan JSON */ }
    if (!r.ok) {
      if (r.status === 401 && token && path.indexOf('/api/admin/login') !== 0) {
        saveToken('');
        showLogin();
      }
      var err = new Error((data && data.error) || ('HTTP ' + r.status));
      err.status = r.status;
      throw err;
    }
    return data;
  }

  function fmtBytes(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(1) + ' MB';
    return (n / 1073741824).toFixed(2) + ' GB';
  }
  function fmtTime(ts) { return ts ? new Date(ts).toLocaleString('id-ID') : '-'; }
  function fmtUp(ms) {
    var s = Math.floor(ms / 1000);
    var d = Math.floor(s / 86400); s -= d * 86400;
    var h = Math.floor(s / 3600); s -= h * 3600;
    var m = Math.floor(s / 60);
    return (d ? d + 'h ' : '') + h + 'j ' + m + 'm';
  }

  function closeStream() {
    if (S.es) { S.es.close(); S.es = null; }
    clearTimeout(S.live);
  }

  // path <-> teks (tiap segmen di-encode, dipisah /)
  function P(arr) { return arr.map(enc).join('/'); }
  function unP(s) { return s ? s.split('/').map(decodeURIComponent) : []; }

  function copyText(t) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = t;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); toast('Disalin: ' + t); } catch (e) { toast('Gagal menyalin', true); }
      document.body.removeChild(ta);
    }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(t).then(function () { toast('Disalin: ' + t); }, fallback);
    } else {
      fallback();
    }
  }

  // ============================================================ modal
  function modalOpen() { return $('#modal').style.display === 'flex'; }
  function modal(title, bodyHtml, okText, onOk) {
    var m = $('#modal');
    m.innerHTML = '<div class="box"><h3 style="margin-top:0">' + esc(title) + '</h3><div id="mbody">' + bodyHtml +
      '</div><div class="row end" style="margin-top:14px"><button class="ghost" id="mcancel">' +
      (okText === null ? 'Tutup' : 'Batal') + '</button>' +
      (okText === null ? '' : '<button id="mok">' + esc(okText || 'OK') + '</button>') + '</div></div>';
    m.style.display = 'flex';
    m.onclick = function (e) { if (e.target === m) closeModal(); };
    m.onchange = null;
    $('#mcancel').onclick = closeModal;
    if (okText !== null) {
      $('#mok').onclick = async function () {
        try { await onOk(); } catch (e) { toast(e.message, true); }
      };
    }
    var first = m.querySelector('input,textarea,select');
    if (first) first.focus();
  }
  function closeModal() {
    var m = $('#modal');
    m.style.display = 'none';
    m.innerHTML = '';
    m.onclick = null;
    m.onchange = null;
  }
  function confirmBox(msg, onYes) {
    modal('Konfirmasi', '<p>' + esc(msg) + '</p>', 'Ya, lanjutkan', async function () {
      closeModal();
      await onYes();
    });
  }
  function actionMenu(title, items) {
    var html = items.map(function (it, i) {
      return '<button class="ghost' + (it.red ? ' danger' : '') + '" data-i="' + i + '" style="display:block;width:100%;margin-bottom:8px;text-align:left">' + esc(it.label) + '</button>';
    }).join('');
    modal(title, html, null);
    $('#mbody').onclick = function (e) {
      var b = e.target.closest('button[data-i]');
      if (!b) return;
      var it = items[Number(b.getAttribute('data-i'))];
      closeModal();
      it.fn();
    };
  }

  // ============================================================ login & kerangka
  function showLogin() {
    closeStream();
    $('#app').innerHTML =
      '<div class="login"><div class="card"><h2>PhoneBase</h2>' +
      '<p class="muted">Masuk sebagai admin. Password awal ada di aplikasi PhoneBase pada HP server.</p>' +
      '<form id="lf"><label>Password admin</label>' +
      '<input type="password" id="pw" autocomplete="current-password">' +
      '<div style="margin-top:12px"><button type="submit" style="width:100%">Masuk</button></div></form></div></div>';
    $('#lf').onsubmit = async function (e) {
      e.preventDefault();
      try {
        var r = await api('POST', '/api/admin/login', { password: $('#pw').value });
        saveToken(r.token);
        showApp();
      } catch (err) {
        toast(err.message, true);
      }
    };
  }

  var VIEWS = {
    home: ['Ringkasan', viewHome],
    db: ['Database', viewDb],
    auth: ['Autentikasi', viewUsers],
    storage: ['Penyimpanan', viewFiles],
    msg: ['Pesan realtime', viewMsg],
    settings: ['Pengaturan & panduan', viewSettings]
  };

  function showApp() {
    var nav = Object.keys(VIEWS).map(function (k) {
      return '<a data-v="' + k + '">' + esc(VIEWS[k][0]) + '</a>';
    }).join('');
    $('#app').innerHTML =
      '<div id="shell"><aside id="side"><div class="brand">PhoneBase</div><div class="srv">' + esc(ORIGIN) + '</div>' +
      '<nav id="nav">' + nav + '</nav><div class="foot"><button class="ghost sm" id="logout">Keluar</button></div></aside>' +
      '<main id="content"><div id="view"></div></main></div>';
    $('#nav').onclick = function (e) {
      var a = e.target.closest('a[data-v]');
      if (!a) return;
      var v = a.getAttribute('data-v');
      if (v === 'db') go('db', S.tab, S.path); else go(v);
    };
    $('#logout').onclick = async function () {
      try { await api('POST', '/api/auth/logout'); } catch (e) { /* abaikan */ }
      saveToken('');
      showLogin();
    };
    render();
  }

  // ---- routing lewat hash: #/db/data/users/ID/banks , #/db/rules , #/auth ...
  function parseHash() {
    var parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean).map(function (x) {
      try { return decodeURIComponent(x); } catch (e) { return x; }
    });
    var view = VIEWS[parts[0]] ? parts[0] : 'home';
    var tab = 'data';
    var path = [];
    if (view === 'db') {
      if (parts[1] === 'rules' || parts[1] === 'usage' || parts[1] === 'data') tab = parts[1];
      if (tab === 'data') path = parts.slice(2);
    }
    return { view: view, tab: tab, path: path };
  }
  function hashFor(view, tab, path) {
    var parts = [view];
    if (view === 'db') {
      parts.push(tab || 'data');
      if ((tab || 'data') === 'data') (path || []).forEach(function (x) { parts.push(x); });
    }
    return '#/' + parts.map(enc).join('/');
  }
  function go(view, tab, path) {
    var h = hashFor(view, tab, path);
    S.pending = true;
    location.hash = h;
    setTimeout(function () { if (S.pending && $('#view')) render(); }, 60);
  }
  window.addEventListener('hashchange', function () { if (token && $('#view')) render(); });

  function render() {
    S.pending = false;
    closeStream();
    var r = parseHash();
    S.view = r.view;
    S.tab = r.tab;
    S.path = r.path;
    var links = document.querySelectorAll('#nav a');
    for (var i = 0; i < links.length; i++) {
      links[i].className = links[i].getAttribute('data-v') === r.view ? 'on' : '';
    }
    var el = $('#view');
    if (!el) return;
    el.onclick = null;
    el.innerHTML = '<p class="muted">Memuat...</p>';
    VIEWS[r.view][1](el, r).catch(function (e) { toast(e.message, true); });
  }

  function statCard(label, value) {
    return '<div class="card stat"><div class="n">' + esc(value) + '</div><div class="l">' + esc(label) + '</div></div>';
  }

  // ============================================================ ringkasan
  async function viewHome(el) {
    var s = await api('GET', '/api/admin/stats');
    el.innerHTML = '<h1>Ringkasan</h1><p class="muted" style="margin-top:0">Server PhoneBase di HP ini berjalan.</p><div class="grid">' +
      statCard('Pengguna', s.users) + statCard('Dokumen', s.docs) + statCard('Koleksi', s.collections) +
      statCard('File', s.files) + statCard('Ukuran file', fmtBytes(s.fileBytes)) +
      statCard('Koneksi realtime', s.connections) + statCard('Total request', s.requests) +
      statCard('Server aktif', fmtUp(s.uptimeMs)) + '</div>' +
      '<h3>Aktivitas data (realtime)</h3><div class="card"><div class="log" id="log"></div></div>';
    renderLog();
    startStream(function (d) {
      S.log.unshift(new Date(d.ts).toLocaleTimeString('id-ID') + '  ' + d.type + '  ' + d.col + '/' + d.id);
      if (S.log.length > 100) S.log.pop();
      renderLog();
    });
  }
  function renderLog() {
    var l = $('#log');
    if (!l) return;
    l.innerHTML = S.log.length
      ? S.log.map(function (x) { return '<div>' + esc(x) + '</div>'; }).join('')
      : '<span class="muted">Belum ada aktivitas. Setiap perubahan dokumen akan muncul di sini secara langsung.</span>';
  }
  function startStream(onDoc) {
    closeStream();
    try {
      var es = new EventSource('/api/realtime?col=*&token=' + enc(token));
      es.addEventListener('doc', function (e) {
        var d;
        try { d = JSON.parse(e.data); } catch (x) { return; }
        onDoc(d);
      });
      S.es = es;
    } catch (e) { /* abaikan */ }
  }

  // ============================================================ database
  var TYPES = ['string', 'number', 'boolean', 'null', 'map', 'array'];

  function typeOf(v) {
    if (v === null) return 'null';
    if (Array.isArray(v)) return 'array';
    if (typeof v === 'object') return 'map';
    return typeof v;
  }
  function cleanView(d) {
    var o = {};
    Object.keys(d || {}).forEach(function (k) {
      if (k !== 'id' && k.charAt(0) !== '_') o[k] = d[k];
    });
    return o;
  }

  async function viewDb(el, r) {
    var tabs = [['data', 'Data'], ['rules', 'Aturan'], ['usage', 'Penggunaan']];
    el.innerHTML = '<h1>Database</h1><div class="tabs" id="dbtabs">' + tabs.map(function (t) {
      return '<a data-t="' + t[0] + '" class="' + (t[0] === r.tab ? 'on' : '') + '">' + t[1] + '</a>';
    }).join('') + '</div><div id="dbbody"></div>';
    $('#dbtabs').onclick = function (e) {
      var a = e.target.closest('a[data-t]');
      if (a) go('db', a.getAttribute('data-t'), a.getAttribute('data-t') === 'data' ? S.path : []);
    };
    var body = $('#dbbody');
    if (r.tab === 'rules') await dbRules(body);
    else if (r.tab === 'usage') await dbUsage(body);
    else await dbData(body, r.path);
  }

  // ---------------------------------------------------------- tab Data
  function item(label, on, p) {
    return '<div class="fitem' + (on ? ' on' : '') + '" data-act="open" data-p="' + esc(p) + '"><span>' + esc(label) +
      '</span><span class="ch">&rsaquo;</span></div>';
  }
  function colWrap(cur, head, inner) {
    return '<div class="fcol' + (cur ? ' cur' : '') + '">' + head + inner + '</div>';
  }
  function backBtn(p) {
    return '<button class="link back" data-act="open" data-p="' + esc(p) + '">&lsaquo;</button>';
  }

  function colRoot(items, sel, cur) {
    var list = items.length
      ? items.map(function (c) { return item(c.name, c.name === sel, P([c.name])); }).join('')
      : '<div class="fempty">Belum ada koleksi. Mulai dengan &quot;Mulai koleksi&quot;.</div>';
    return colWrap(cur, '<div class="fhead"><span class="t">(default)</span></div>',
      '<div class="fact" data-act="newcoll" data-p="">+ Mulai koleksi</div><div class="flist">' + list + '</div>');
  }

  function colDocs(coll, r, sel, cur) {
    var key = P(coll);
    var title = coll[coll.length - 1];
    var head = '<div class="fhead">' + backBtn(P(coll.slice(0, -1))) + '<span class="t">' + esc(title) + '</span>' +
      '<button class="link" data-act="filter" data-p="' + esc(key) + '">Filter</button>' +
      '<button class="link" data-act="collmenu" data-p="' + esc(key) + '">&#8942;</button></div>';
    var inner = '<div class="fact" data-act="newdoc" data-p="' + esc(key) + '">+ Tambah dokumen</div><div class="flist">';
    if (S.flt[key]) {
      inner += '<div class="fempty" style="padding:8px 14px"><span class="tag">filter: ' + esc(S.flt[key]) +
        '</span> <button class="link" data-act="clrfilter" data-p="' + esc(key) + '">hapus</button></div>';
    }
    if (!r.items.length) inner += '<div class="fempty">Tidak ada dokumen.</div>';
    inner += r.items.map(function (d) { return item(d.id, d.id === sel, P(coll.concat([d.id]))); }).join('');
    if (r.count > r.items.length) {
      inner += '<div class="fempty"><button class="link" data-act="more" data-p="' + esc(key) + '">Muat lebih banyak (' +
        (r.count - r.items.length) + ' lagi)</button></div>';
    }
    return colWrap(cur, head, inner + '</div>');
  }

  function fieldRows(key, v, depth, top, dp) {
    var t = typeOf(v);
    var pad = 14 + depth * 18;
    var ops = top
      ? '<span class="ops"><button class="link" data-act="editfield" data-p="' + esc(dp) + '" data-k="' + esc(key) + '">ubah</button>' +
        '<button class="link red" data-act="delfield" data-p="' + esc(dp) + '" data-k="' + esc(key) + '">hapus</button></span>'
      : '';
    var out = '';
    if (t === 'map' || t === 'array') {
      var keys = Object.keys(v);
      out += '<div class="fld sub" style="padding-left:' + pad + 'px"><span class="k">' + esc(key) + '</span>:<span class="v z">(' +
        t + (keys.length ? '' : ', kosong') + ')</span>' + ops + '</div>';
      keys.forEach(function (k) { out += fieldRows(k, v[k], depth + 1, false, dp); });
      return out;
    }
    var cls = 'z', txt = 'null';
    if (t === 'string') { cls = 's'; txt = JSON.stringify(v); }
    else if (t === 'number') { cls = 'n'; txt = String(v); }
    else if (t === 'boolean') { cls = 'b'; txt = String(v); }
    return '<div class="fld" style="padding-left:' + pad + 'px"><span class="k">' + esc(key) + '</span>:<span class="v ' + cls + '">' +
      esc(txt) + '</span>' + ops + '</div>';
  }

  function colDetail(docPath, doc, subs, sel, cur) {
    var dp = P(docPath);
    var head = '<div class="fhead">' + backBtn(P(docPath.slice(0, -1))) + '<span class="t">' + esc(docPath[docPath.length - 1]) + '</span>' +
      '<button class="link" data-act="docmenu" data-p="' + esc(dp) + '">&#8942;</button></div>';
    var inner = '<div class="fact" data-act="newcoll" data-p="' + esc(dp) + '">+ Mulai koleksi</div><div class="flist">';
    if (subs.length) {
      inner += subs.map(function (n) { return item(n, n === sel, P(docPath.concat([n]))); }).join('');
      inner += '<div style="border-bottom:1px solid var(--line);margin-top:6px"></div>';
    }
    inner += '<div class="fact" data-act="addfield" data-p="' + esc(dp) + '" style="border-top:1px solid var(--line)">+ Tambah field</div>';
    var clean = cleanView(doc);
    var keys = Object.keys(clean);
    inner += keys.length ? keys.map(function (k) { return fieldRows(k, clean[k], 0, true, dp); }).join('')
      : '<div class="fempty">Dokumen ini belum punya field.</div>';
    inner += '</div><div class="meta">dibuat ' + esc(fmtTime(doc._created)) + ' &middot; diubah ' + esc(fmtTime(doc._updated)) +
      (doc._owner ? ' &middot; pemilik ' + esc(doc._owner) : '') + '</div>';
    return colWrap(cur, head, inner);
  }

  async function dbData(body, path, silent) {
    var seq = ++S.seq;
    var cols = [{ t: 'root' }];
    for (var k = 0; path.length >= 2 * k + 1; k++) {
      cols.push({ t: 'docs', coll: path.slice(0, 2 * k + 1) });
      if (path.length >= 2 * k + 2) cols.push({ t: 'detail', doc: path.slice(0, 2 * k + 2) });
    }
    var vis = cols.slice(-3);
    var curIdx = vis.length - 1;
    while (vis.length < 3) vis.push({ t: 'blank' });

    var jobs = vis.map(function (c) {
      if (c.t === 'root') return api('GET', '/api/admin/collections').then(function (r) { return r.items; });
      if (c.t === 'docs') {
        var key = P(c.coll);
        var q = '?limit=' + (S.lim[key] || 50);
        if (S.flt[key]) q += '&where=' + enc(S.flt[key]);
        return api('GET', '/api/db/' + key + q);
      }
      if (c.t === 'detail') {
        return Promise.all([
          api('GET', '/api/db/' + P(c.doc)),
          api('GET', '/api/admin/subcollections?path=' + enc(c.doc.join('/')))
        ]).then(function (r) { return { doc: r[0], subs: r[1].items }; });
      }
      return Promise.resolve(null);
    });

    var res;
    try {
      res = await Promise.all(jobs);
    } catch (e) {
      if (seq !== S.seq) return;
      if (path.length) {
        toast(e.message, true);
        go('db', 'data', path.slice(0, -1));
        return;
      }
      throw e;
    }
    if (seq !== S.seq) return;

    var scr = [];
    Array.prototype.forEach.call(body.querySelectorAll('.flist'), function (n) { scr.push(n.scrollTop); });

    var html = vis.map(function (c, i) {
      var cur = i === curIdx;
      if (c.t === 'root') return colRoot(res[i], path[0], cur);
      if (c.t === 'docs') return colDocs(c.coll, res[i], path[c.coll.length], cur);
      if (c.t === 'detail') return colDetail(c.doc, res[i].doc, res[i].subs, path[c.doc.length], cur);
      return '<div class="fcol"><div class="fhead">&nbsp;</div></div>';
    }).join('');

    var crumb = '<div class="crumb"><a data-act="open" data-p="">Database</a>';
    path.forEach(function (seg, i) {
      crumb += '<span>&rsaquo;</span><a data-act="open" data-p="' + esc(P(path.slice(0, i + 1))) + '">' + esc(seg) + '</a>';
    });
    crumb += '</div>';

    body.innerHTML = crumb + '<div class="fs">' + html + '</div>';
    Array.prototype.forEach.call(body.querySelectorAll('.flist'), function (n, i) { if (scr[i]) n.scrollTop = scr[i]; });
    body.onclick = function (e) { dbClick(e, body); };

    if (!silent) {
      startStream(function () {
        clearTimeout(S.live);
        S.live = setTimeout(function () {
          if (S.view === 'db' && S.tab === 'data' && !modalOpen() && $('#dbbody')) {
            dbData($('#dbbody'), S.path, true).catch(function () { /* abaikan */ });
          }
        }, 500);
      });
    }
  }

  function refresh() {
    var b = $('#dbbody');
    if (b && S.view === 'db' && S.tab === 'data') return dbData(b, S.path, true);
    return Promise.resolve();
  }

  async function saveDocFields(docPath, mut) {
    var d = await api('GET', '/api/db/' + P(docPath));
    var o = cleanView(d);
    mut(o);
    await api('PUT', '/api/db/' + P(docPath), o);
  }

  function dbClick(e) {
    var b = e.target.closest('[data-act]');
    if (!b) return;
    var act = b.getAttribute('data-act');
    var p = unP(b.getAttribute('data-p') || '');
    var key = b.getAttribute('data-k');
    var run = function (pr) { pr.catch(function (err) { toast(err.message, true); }); };

    if (act === 'open') go('db', 'data', p);
    else if (act === 'newcoll') modalDoc(p, true);
    else if (act === 'newdoc') modalDoc(p, false);
    else if (act === 'addfield') modalField(p, null);
    else if (act === 'editfield') modalField(p, key);
    else if (act === 'delfield') {
      confirmBox('Hapus field "' + key + '"?', async function () {
        await saveDocFields(p, function (o) { delete o[key]; });
        toast('Field dihapus');
        await refresh();
      });
    } else if (act === 'docmenu') {
      actionMenu('Dokumen ' + p[p.length - 1], [
        { label: 'Salin path', fn: function () { copyText(p.join('/')); } },
        {
          label: 'Hapus dokumen', red: true, fn: function () {
            confirmBox('Hapus dokumen ' + p.join('/') + '? Sub-koleksinya tidak ikut terhapus (hapus lewat menu koleksinya).', async function () {
              await api('DELETE', '/api/db/' + P(p));
              toast('Dokumen dihapus');
              go('db', 'data', p.slice(0, -1));
            });
          }
        }
      ]);
    } else if (act === 'collmenu') {
      actionMenu('Koleksi ' + p[p.length - 1], [
        { label: 'Salin path', fn: function () { copyText(p.join('/')); } },
        {
          label: 'Hapus koleksi', red: true, fn: function () {
            confirmBox('Hapus SEMUA dokumen di "' + p.join('/') + '" beserta sub-koleksinya? Tidak bisa dibatalkan.', async function () {
              await api('DELETE', '/api/admin/collections?path=' + enc(p.join('/')));
              toast('Koleksi dihapus');
              go('db', 'data', p.slice(0, -1));
            });
          }
        }
      ]);
    } else if (act === 'filter') {
      modalFilter(p);
    } else if (act === 'clrfilter') {
      delete S.flt[P(p)];
      run(refresh());
    } else if (act === 'more') {
      var kk = P(p);
      S.lim[kk] = (S.lim[kk] || 50) + 50;
      run(refresh());
    }
  }

  // ---- baris field di modal
  function fieldRowHtml(name, type, val, fixedName) {
    return '<div class="frow"><input class="fn" placeholder="nama field" value="' + esc(name) + '" style="flex:1.1"' + (fixedName ? '' : '') + '>' +
      '<select class="ft" style="flex:.8">' + TYPES.map(function (t) {
        return '<option' + (t === type ? ' selected' : '') + '>' + t + '</option>';
      }).join('') + '</select>' +
      '<textarea class="fv" placeholder="nilai" style="flex:1.4;min-height:38px;height:38px">' + esc(val) + '</textarea>' +
      '<button class="link red" data-x="1" title="hapus baris">&times;</button></div>';
  }
  function hintFor(type) {
    if (type === 'boolean') return 'true atau false';
    if (type === 'number') return 'angka, mis. 25000';
    if (type === 'null') return '(kosong)';
    if (type === 'map') return '{"kunci": "nilai"}';
    if (type === 'array') return '["a", "b"]';
    return 'teks';
  }
  function wireRows() {
    var m = $('#modal');
    var apply = function (sel) {
      var row = sel.closest('.frow');
      var fv = row.querySelector('.fv');
      fv.placeholder = hintFor(sel.value);
      fv.disabled = sel.value === 'null';
      if (sel.value === 'null') fv.value = '';
    };
    m.onchange = function (e) { if (e.target.classList.contains('ft')) apply(e.target); };
    Array.prototype.forEach.call(m.querySelectorAll('.ft'), apply);
    m.onclick = function (e) {
      if (e.target === m) { closeModal(); return; }
      var x = e.target.closest('[data-x]');
      if (x) { var row = x.closest('.frow'); if (row && row.parentNode) row.parentNode.removeChild(row); }
    };
  }
  function parseValue(type, txt) {
    var t = String(txt);
    if (type === 'string') return t;
    if (type === 'null') return null;
    if (type === 'number') {
      var n = Number(t.trim());
      if (t.trim() === '' || !isFinite(n)) throw new Error('Nilai harus berupa angka');
      return n;
    }
    if (type === 'boolean') {
      var b = t.trim().toLowerCase();
      if (b !== 'true' && b !== 'false') throw new Error('Nilai boolean harus true atau false');
      return b === 'true';
    }
    var v;
    try { v = JSON.parse(t); } catch (e) { throw new Error('Nilai ' + type + ' harus JSON yang valid'); }
    if (type === 'array' && !Array.isArray(v)) throw new Error('Nilai array harus diawali [ ]');
    if (type === 'map' && (v === null || typeof v !== 'object' || Array.isArray(v))) throw new Error('Nilai map harus diawali { }');
    return v;
  }
  function checkFieldName(n) {
    if (!n) throw new Error('Nama field wajib diisi');
    if (n === 'id' || n.charAt(0) === '_') throw new Error('Nama field tidak boleh "id" atau diawali _ (dipakai sistem)');
  }
  function collectRows() {
    var out = {};
    var rows = document.querySelectorAll('#modal .frow');
    for (var i = 0; i < rows.length; i++) {
      var name = rows[i].querySelector('.fn').value.trim();
      var type = rows[i].querySelector('.ft').value;
      var txt = rows[i].querySelector('.fv').value;
      if (!name && !txt.trim() && type === 'string') continue;
      checkFieldName(name);
      if (Object.prototype.hasOwnProperty.call(out, name)) throw new Error('Nama field ganda: ' + name);
      out[name] = parseValue(type, txt);
    }
    return out;
  }

  // ---- modal: mulai koleksi / tambah dokumen
  function modalDoc(parent, newColl) {
    var where = parent.length ? '<p class="muted" style="margin-top:0">Di dalam <code>' + esc(parent.join('/')) + '</code></p>' : '';
    var html = where +
      (newColl ? '<label>ID koleksi</label><input id="ncid" placeholder="mis. produk">' : '<p class="muted" style="margin-top:0">Koleksi <code>' + esc(parent.join('/')) + '</code></p>') +
      '<label>ID dokumen (kosongkan untuk ID otomatis)</label><input id="ndid">' +
      '<label>Field</label><div id="frows">' + fieldRowHtml('', 'string', '') + '</div>' +
      '<button class="link" id="addrow">+ Tambah field</button>';
    modal(newColl ? 'Mulai koleksi' : 'Tambah dokumen', html, 'Simpan', async function () {
      var collPath = parent;
      if (newColl) {
        var cid = $('#ncid').value.trim();
        if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/.test(cid)) throw new Error('ID koleksi tidak valid (huruf/angka/_ - . , maks 64)');
        collPath = parent.concat([cid]);
      }
      var did = $('#ndid').value.trim();
      if (did && !/^[A-Za-z0-9][A-Za-z0-9_.:@-]{0,127}$/.test(did)) throw new Error('ID dokumen tidak valid');
      var data = collectRows();
      var res;
      if (did) {
        var exists = true;
        try { await api('GET', '/api/db/' + P(collPath.concat([did]))); } catch (e) { exists = false; }
        if (exists) throw new Error('ID dokumen sudah dipakai');
        res = await api('PUT', '/api/db/' + P(collPath.concat([did])), data);
      } else {
        res = await api('POST', '/api/db/' + P(collPath), data);
      }
      closeModal();
      toast('Tersimpan');
      go('db', 'data', collPath.concat([res.id]));
    });
    wireRows();
    $('#addrow').onclick = function () {
      $('#frows').insertAdjacentHTML('beforeend', fieldRowHtml('', 'string', ''));
      wireRows();
    };
  }

  // ---- modal: tambah / ubah field
  async function modalField(docPath, key) {
    var name = '', type = 'string', val = '';
    if (key !== null) {
      var d = await api('GET', '/api/db/' + P(docPath));
      var v = d[key];
      name = key;
      type = typeOf(v);
      val = (type === 'map' || type === 'array') ? JSON.stringify(v, null, 2) : (type === 'null' ? '' : String(v));
    }
    modal(key === null ? 'Tambah field' : 'Ubah field', fieldRowHtml(name, type, val), 'Simpan', async function () {
      var data = collectRows();
      var names = Object.keys(data);
      if (names.length !== 1) throw new Error('Isi nama field');
      var nn = names[0];
      await saveDocFields(docPath, function (o) {
        if (key !== null && key !== nn) delete o[key];
        o[nn] = data[nn];
      });
      closeModal();
      toast('Tersimpan');
      await refresh();
    });
    wireRows();
    var x = $('#modal [data-x]');
    if (x) x.style.display = 'none';
  }

  // ---- modal: filter dokumen
  function modalFilter(coll) {
    var key = P(coll);
    var cur = (S.flt[key] || '').split(':');
    var ops = ['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'contains'];
    var labels = { eq: '= sama dengan', ne: '!= tidak sama', gt: '> lebih dari', gte: '>= minimal', lt: '< kurang dari', lte: '<= maksimal', contains: 'mengandung' };
    var html = '<label>Field</label><input id="ffield" value="' + esc(cur[0] || '') + '">' +
      '<label>Operator</label><select id="fop">' + ops.map(function (o) {
        return '<option value="' + o + '"' + (o === cur[1] ? ' selected' : '') + '>' + labels[o] + '</option>';
      }).join('') + '</select>' +
      '<label>Nilai</label><input id="fval" value="' + esc(cur.slice(2).join(':')) + '">';
    modal('Filter dokumen di ' + coll.join('/'), html, 'Terapkan', async function () {
      var f = $('#ffield').value.trim();
      if (!f) { delete S.flt[key]; } else { S.flt[key] = f + ':' + $('#fop').value + ':' + $('#fval').value; }
      closeModal();
      await refresh();
    });
  }

  // ---------------------------------------------------------- tab Aturan
  function lineNums(n) {
    var a = [];
    for (var i = 1; i <= n; i++) a.push(i);
    return a.join('\n');
  }

  async function dbRules(body) {
    var seq = ++S.seq;
    var rs = await Promise.all([api('GET', '/api/admin/rules/current'), api('GET', '/api/admin/rules/history')]);
    if (seq !== S.seq) return;
    var cur = rs[0];
    var hist = rs[1].items;
    var published = cur.text;
    var viewingOld = false;

    var histHtml = hist.length
      ? hist.map(function (h, i) {
        return '<div class="hi' + (i === 0 ? ' live on' : '') + '" data-v="' + h.version + '">' + esc(fmtTime(h.created)) +
          '<small>versi ' + h.version + (i === 0 ? ' &middot; berlaku' : '') + '</small></div>';
      }).join('')
      : '<div class="hi live on" data-v="cur">Bawaan<small>belum pernah dipublikasikan</small></div>';

    body.innerHTML = '<div class="rl"><div class="hist" id="rhist">' + histHtml + '</div><div class="ed">' +
      '<div class="row" style="margin-bottom:10px"><span class="grow muted" id="rinfo"></span>' +
      '<button class="ghost" id="rtest">Develop &amp; Test</button><button id="rpub" disabled>Publikasikan</button></div>' +
      '<div class="card" id="rsim" style="display:none;margin-bottom:10px"><b>Uji aturan</b> <span class="muted">(memakai teks di editor, belum perlu dipublikasikan)</span>' +
      '<div class="row" style="margin-top:8px"><select id="sop" style="width:auto"><option value="read">read (baca)</option><option value="write">write (tulis)</option></select>' +
      '<input id="spath" class="grow" value="users/abc123" placeholder="path, mis. users/abc123/banks">' +
      '<select id="swho" style="width:auto"><option value="anon">Tanpa login</option><option value="user">Login (bukan pemilik)</option><option value="owner">Pemilik dokumen</option><option value="admin">Admin</option></select>' +
      '<button id="srun">Jalankan</button></div><div id="sres" style="margin-top:8px"></div></div>' +
      '<div class="edbox"><div class="gut" id="gut"></div><textarea id="rta" spellcheck="false" wrap="off"></textarea></div>' +
      '<details class="card" style="margin-top:10px"><summary style="cursor:pointer">Bantuan format aturan</summary>' +
      '<p>Tulis blok <code>match /koleksi/{doc}</code> dengan baris <code>allow read</code> / <code>allow write</code>. Kondisi yang dikenal:</p>' +
      '<ul><li><code>true</code> &ndash; siapa saja</li><li><code>signedIn()</code> &ndash; harus login</li>' +
      '<li><code>isOwner()</code> &ndash; hanya pembuat dokumen (khusus write)</li><li><code>isAdmin()</code> atau <code>false</code> &ndash; hanya admin</li></ul>' +
      '<p>Aturan koleksi berlaku juga untuk sub-koleksinya. <code>match /{document=**}</code> adalah aturan bawaan. ' +
      '<code>/_files/{doc}</code> mengatur file dan <code>/ch:nama/{doc}</code> mengatur channel pesan. Admin selalu boleh. ' +
      'Kalau suatu operasi tidak ditulis di sebuah blok, operasi itu ditolak.</p></details></div></div>';

    var ta = $('#rta'), gut = $('#gut'), pub = $('#rpub'), info = $('#rinfo');
    ta.value = published;
    function upd() {
      gut.textContent = lineNums(ta.value.split('\n').length);
      pub.disabled = !(ta.value !== published || viewingOld);
      info.textContent = viewingOld ? 'Melihat versi lama. Tekan Publikasikan untuk memakainya lagi.'
        : (ta.value !== published ? 'Ada perubahan yang belum dipublikasikan.' : (cur.version ? 'Versi ' + cur.version + ' sedang berlaku.' : 'Aturan bawaan sedang berlaku.'));
    }
    ta.oninput = upd;
    ta.onscroll = function () { gut.scrollTop = ta.scrollTop; };
    upd();

    $('#rhist').onclick = async function (e) {
      var h = e.target.closest('.hi');
      if (!h) return;
      var v = h.getAttribute('data-v');
      try {
        if (v === 'cur' || (hist.length && v === String(hist[0].version))) {
          ta.value = published;
          viewingOld = false;
        } else {
          var o = await api('GET', '/api/admin/rules/history/' + enc(v));
          ta.value = o.text;
          viewingOld = true;
        }
        Array.prototype.forEach.call(document.querySelectorAll('#rhist .hi'), function (n) {
          n.className = 'hi' + (n === h ? ' on' : '') + (n === document.querySelector('#rhist .hi') ? ' live' : '');
        });
        upd();
      } catch (err) { toast(err.message, true); }
    };

    pub.onclick = async function () {
      try {
        var r = await api('PUT', '/api/admin/rules', { text: ta.value });
        toast('Aturan dipublikasikan (versi ' + r.version + ')');
        await dbRules(body);
      } catch (err) { toast(err.message, true); }
    };
    $('#rtest').onclick = function () {
      var s = $('#rsim');
      s.style.display = s.style.display === 'none' ? 'block' : 'none';
    };
    $('#srun').onclick = async function () {
      var out = $('#sres');
      try {
        var r = await api('POST', '/api/admin/rules/test', {
          text: ta.value, path: $('#spath').value, op: $('#sop').value, who: $('#swho').value
        });
        out.innerHTML = (r.allowed ? '<b class="ok">&#10004; Diizinkan</b>' : '<b class="bad">&#10008; Ditolak</b>') +
          ' <span class="muted">&middot; aturan: ' + esc(r.rule) + '</span>';
      } catch (err) {
        out.innerHTML = '<b class="bad">' + esc(err.message) + '</b>';
      }
    };
  }

  // ---------------------------------------------------------- tab Penggunaan
  async function dbUsage(body) {
    var seq = ++S.seq;
    var rs = await Promise.all([api('GET', '/api/admin/stats'), api('GET', '/api/admin/collections')]);
    if (seq !== S.seq) return;
    var s = rs[0];
    var rows = rs[1].items.map(function (c) {
      return '<tr><td><code>' + esc(c.name) + '</code></td><td>' + c.count + '</td><td>' + esc(c.read) + '</td><td>' + esc(c.write) + '</td></tr>';
    }).join('');
    body.innerHTML = '<div class="grid">' + statCard('Dokumen', s.docs) + statCard('Koleksi tingkat atas', s.collections) +
      statCard('Ukuran database', fmtBytes(s.dbBytes)) + statCard('File', s.files) + statCard('Ukuran file', fmtBytes(s.fileBytes)) +
      statCard('Koneksi realtime', s.connections) + statCard('Total request', s.requests) + statCard('Server aktif', fmtUp(s.uptimeMs)) + '</div>' +
      '<h3>Koleksi tingkat atas</h3><div class="card tw"><table><thead><tr><th>Koleksi</th><th>Dokumen langsung</th><th>Baca</th><th>Tulis</th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="4" class="muted">Belum ada koleksi.</td></tr>') + '</tbody></table></div>' +
      '<p class="muted">Kolom Baca/Tulis adalah hasil aturan yang berlaku (lihat tab Aturan).</p>';
  }

  // ============================================================ autentikasi
  async function viewUsers(el) {
    var r = await api('GET', '/api/admin/users');
    var st = await api('GET', '/api/admin/stats');
    var rows = r.items.map(function (u) {
      return '<tr><td>' + esc(u.email) + '</td>' +
        '<td>' + (u.disabled ? '<span class="tag bad">nonaktif</span>' : '<span class="tag ok">aktif</span>') + '</td>' +
        '<td>' + esc(fmtTime(u.created)) + '</td><td><code>' + esc(u.id) + '</code></td><td><div class="row">' +
        '<button class="link" data-act="toggle" data-id="' + esc(u.id) + '" data-dis="' + (u.disabled ? 0 : 1) + '">' + (u.disabled ? 'Aktifkan' : 'Nonaktifkan') + '</button>' +
        '<button class="link" data-act="pw" data-id="' + esc(u.id) + '" data-mail="' + esc(u.email) + '">Reset password</button>' +
        '<button class="link red" data-act="del" data-id="' + esc(u.id) + '" data-mail="' + esc(u.email) + '">Hapus</button></div></td></tr>';
    }).join('');
    el.innerHTML = '<h1>Autentikasi</h1><div class="tabs"><a class="on">Pengguna</a></div>' +
      '<div class="row" style="margin-bottom:12px"><button id="uadd">Tambah pengguna</button><span class="grow"></span>' +
      '<label style="margin:0;display:flex;align-items:center;gap:6px"><input type="checkbox" id="reg"' + (st.allowRegister ? ' checked' : '') + '> Izinkan pendaftaran mandiri dari aplikasi</label></div>' +
      '<div class="card tw"><table><thead><tr><th>Identitas (email)</th><th>Status</th><th>Dibuat</th><th>UID</th><th></th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="5" class="muted">Belum ada pengguna.</td></tr>') + '</tbody></table></div>';
    $('#uadd').onclick = function () {
      modal('Tambah pengguna', '<label>Email</label><input id="ue"><label>Password (min 6)</label><input id="up">', 'Tambah', async function () {
        await api('POST', '/api/admin/users', { email: $('#ue').value, password: $('#up').value });
        closeModal();
        toast('Pengguna ditambahkan');
        viewUsers(el);
      });
    };
    $('#reg').onchange = async function () {
      try {
        await api('PUT', '/api/admin/settings', { allowRegister: $('#reg').checked });
        toast('Pengaturan disimpan');
      } catch (e) { toast(e.message, true); }
    };
    el.onclick = function (e) {
      var b = e.target.closest('[data-act]');
      if (!b) return;
      var act = b.getAttribute('data-act');
      var id = b.getAttribute('data-id');
      if (act === 'toggle') {
        api('PUT', '/api/admin/users/' + enc(id), { disabled: b.getAttribute('data-dis') === '1' })
          .then(function () { viewUsers(el); }).catch(function (err) { toast(err.message, true); });
      } else if (act === 'pw') {
        modal('Reset password ' + b.getAttribute('data-mail'), '<label>Password baru (min 6)</label><input id="npw">', 'Simpan', async function () {
          await api('PUT', '/api/admin/users/' + enc(id), { password: $('#npw').value });
          closeModal();
          toast('Password diganti');
        });
      } else if (act === 'del') {
        confirmBox('Hapus pengguna ' + b.getAttribute('data-mail') + '?', async function () {
          await api('DELETE', '/api/admin/users/' + enc(id));
          toast('Pengguna dihapus');
          viewUsers(el);
        });
      }
    };
  }

  // ============================================================ penyimpanan (file)
  async function viewFiles(el) {
    var r = await api('GET', '/api/files');
    var rows = r.items.map(function (f) {
      var url = '/api/files/' + enc(f.id) + '?token=' + enc(token);
      var thumb = String(f.mime).indexOf('image/') === 0 ? '<img class="thumb" src="' + url + '" alt="">' : '';
      return '<tr><td>' + thumb + '</td><td>' + esc(f.name) + '<div class="muted" style="font-size:12px">' + esc(f.id) + '</div></td>' +
        '<td>' + esc(fmtBytes(f.size)) + '</td><td>' + esc(fmtTime(f.created)) + '</td><td><div class="row">' +
        '<a class="btn sm" style="text-decoration:none" href="' + url + '&download=1">Unduh</a>' +
        '<button class="link red" data-act="del" data-id="' + esc(f.id) + '" data-name="' + esc(f.name) + '">Hapus</button></div></td></tr>';
    }).join('');
    el.innerHTML = '<h1>Penyimpanan</h1><div class="tabs"><a class="on">File</a></div>' +
      '<div class="card"><div class="row"><input type="file" id="fup" class="grow"><button id="fgo">Upload</button></div>' +
      '<p class="muted" style="margin:8px 0 0;font-size:12px">Maksimal 200 MB per file. Aplikasi bisa mengunggah lewat POST /api/files. Hak akses file diatur lewat <code>/_files/{doc}</code> di tab Aturan.</p></div>' +
      '<div class="card tw" style="margin-top:10px"><table><thead><tr><th></th><th>Nama</th><th>Ukuran</th><th>Diunggah</th><th></th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="5" class="muted">Belum ada file.</td></tr>') + '</tbody></table></div>';
    $('#fgo').onclick = async function () {
      var inp = $('#fup');
      if (!inp.files || !inp.files.length) { toast('Pilih file dulu', true); return; }
      var file = inp.files[0];
      try {
        toast('Mengunggah ' + file.name + '...');
        var resp = await fetch('/api/files?name=' + enc(file.name), {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': file.type || 'application/octet-stream' },
          body: file
        });
        var d = null;
        try { d = await resp.json(); } catch (e) { /* abaikan */ }
        if (!resp.ok) throw new Error((d && d.error) || ('HTTP ' + resp.status));
        toast('Upload selesai');
        viewFiles(el);
      } catch (e) { toast(e.message, true); }
    };
    el.onclick = function (e) {
      var b = e.target.closest('[data-act="del"]');
      if (!b) return;
      var id = b.getAttribute('data-id');
      confirmBox('Hapus file ' + b.getAttribute('data-name') + '?', async function () {
        await api('DELETE', '/api/files/' + enc(id));
        toast('File dihapus');
        viewFiles(el);
      });
    };
  }

  // ============================================================ pesan realtime
  async function viewMsg(el) {
    el.innerHTML = '<h1>Pesan realtime</h1><div class="tabs"><a class="on">Channel</a></div><div class="card">' +
      '<label style="margin-top:0">Nama channel</label><input id="ch" value="umum">' +
      '<label>Pesan (teks atau JSON)</label><textarea id="mt" style="min-height:70px">halo dari dashboard</textarea>' +
      '<div class="row" style="margin-top:10px"><button id="msend">Kirim</button><button class="ghost" id="msub">Dengarkan channel</button></div></div>' +
      '<h3>Pesan masuk</h3><div class="card"><div class="log" id="mlog"><span class="muted">Tekan "Dengarkan channel" untuk melihat pesan yang masuk.</span></div></div>';
    $('#msend').onclick = async function () {
      var raw = $('#mt').value;
      var val = raw;
      try { val = JSON.parse(raw); } catch (e) { /* kirim sebagai teks */ }
      try {
        var r = await api('POST', '/api/channels/' + enc($('#ch').value.trim()) + '/publish', { message: val });
        toast('Terkirim ke ' + r.delivered + ' pendengar');
      } catch (e) { toast(e.message, true); }
    };
    $('#msub').onclick = function () {
      closeStream();
      var name = $('#ch').value.trim();
      var log = $('#mlog');
      log.innerHTML = '<div class="muted">Mendengarkan channel "' + esc(name) + '"...</div>';
      var es = new EventSource('/api/realtime?channel=' + enc(name) + '&token=' + enc(token));
      es.addEventListener('msg', function (e) {
        var d = JSON.parse(e.data);
        var line = document.createElement('div');
        line.textContent = new Date(d.ts).toLocaleTimeString('id-ID') + '  ' + (d.from || 'anon') + ': ' + JSON.stringify(d.message);
        log.insertBefore(line, log.children[1] || null);
      });
      S.es = es;
    };
  }

  // ============================================================ pengaturan & panduan
  async function viewSettings(el) {
    var js = [
      '<script src="' + ORIGIN + '/phonebase.js"></script>',
      '<script>',
      '  const pb = PhoneBase("' + ORIGIN + '");',
      '  await pb.register("user@mail.com", "rahasia123");   // atau pb.login(...)',
      '  const todos = pb.collection("todos");',
      '  await todos.add({ judul: "Beli susu", selesai: false });',
      '  const hasil = await todos.list({ where: ["selesai:eq:false"], order: "-_created" });',
      '  todos.listen(function (e) { console.log(e.type, e.id, e.data); });',
      '  // sub-koleksi: koleksi/dokumen/sub-koleksi',
      '  const banks = pb.collection("users/" + pb.user.id + "/banks");',
      '  pb.channel("umum").listen(function (m) { console.log(m.message); });',
      '</script>'
    ].join('\n');
    var curl = [
      'curl -X POST ' + ORIGIN + '/api/auth/login \\',
      '  -H "Content-Type: application/json" \\',
      '  -d \'{"email":"user@mail.com","password":"rahasia123"}\'',
      '',
      'curl ' + ORIGIN + '/api/db/todos -H "Authorization: Bearer TOKEN"',
      '',
      'curl -X POST ' + ORIGIN + '/api/db/users/UID/banks \\',
      '  -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" \\',
      '  -d \'{"nama":"BCA"}\''
    ].join('\n');
    el.innerHTML = '<h1>Pengaturan &amp; panduan</h1><div class="tabs"><a class="on">Umum</a></div>' +
      '<div class="card"><b>Ganti password admin</b><div class="row" style="margin-top:8px"><input class="grow" id="apw" type="password" placeholder="password baru (min 8)">' +
      '<button id="asave">Simpan</button></div></div>' +
      '<h3>Alamat server</h3><div class="card"><code>' + esc(ORIGIN) + '</code>' +
      '<p class="muted" style="margin-bottom:0">Pakai alamat ini di aplikasi/situs Anda. Dari internet, gunakan alamat Tailscale atau Cloudflare Tunnel (lihat README).</p></div>' +
      '<h3>Contoh pakai (JavaScript)</h3><pre>' + esc(js) + '</pre>' +
      '<h3>Contoh pakai (curl)</h3><pre>' + esc(curl) + '</pre>' +
      '<h3>Endpoint ringkas</h3><div class="card tw"><table><tbody>' +
      '<tr><td><code>POST /api/auth/register</code></td><td>daftar user, balas token</td></tr>' +
      '<tr><td><code>POST /api/auth/login</code></td><td>login user, balas token</td></tr>' +
      '<tr><td><code>GET /api/db/{koleksi}</code></td><td>daftar dokumen (?where=f:op:v &amp;order= &amp;limit= &amp;offset=)</td></tr>' +
      '<tr><td><code>POST /api/db/{koleksi}</code></td><td>tambah dokumen</td></tr>' +
      '<tr><td><code>GET/PUT/PATCH/DELETE /api/db/{koleksi}/{id}</code></td><td>baca / ganti / gabung / hapus</td></tr>' +
      '<tr><td><code>/api/db/{koleksi}/{id}/{sub}/{id2}</code></td><td>sub-koleksi (boleh bersarang sampai 6 tingkat)</td></tr>' +
      '<tr><td><code>GET /api/realtime?col=...&amp;token=...</code></td><td>stream perubahan dokumen (SSE)</td></tr>' +
      '<tr><td><code>GET /api/realtime?channel=...&amp;token=...</code></td><td>stream pesan channel</td></tr>' +
      '<tr><td><code>POST /api/channels/{nama}/publish</code></td><td>kirim pesan ke channel</td></tr>' +
      '<tr><td><code>POST /api/files?name=...</code></td><td>unggah file (body = isi file)</td></tr>' +
      '<tr><td><code>GET /api/files/{id}</code></td><td>ambil file</td></tr>' +
      '</tbody></table></div>';
    $('#asave').onclick = async function () {
      try {
        await api('POST', '/api/admin/password', { password: $('#apw').value });
        $('#apw').value = '';
        toast('Password admin diganti');
      } catch (e) { toast(e.message, true); }
    };
  }

  // ============================================================ mulai
  if (token) {
    api('GET', '/api/admin/stats').then(showApp).catch(function () { showLogin(); });
  } else {
    showLogin();
  }
})();
