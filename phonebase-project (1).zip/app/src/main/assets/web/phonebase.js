/*
 * PhoneBase JavaScript SDK
 * Pakai di web / WebView:  <script src="http://ALAMAT-SERVER:8080/phonebase.js"></script>
 *
 *   const pb = PhoneBase('http://192.168.1.10:8080');
 *   await pb.register('a@b.com', 'rahasia123');   // atau pb.login(...)
 *   const todos = pb.collection('todos');
 *   await todos.add({ judul: 'Beli susu' });
 *   const r = await todos.list({ where: ['selesai:eq:false'], order: '-_created', limit: 50 });
 *   const stop = todos.listen(function (e) { console.log(e.type, e.id, e.data); });
 */
(function (global) {
  'use strict';

  function PhoneBase(url, options) {
    if (!(this instanceof PhoneBase)) return new PhoneBase(url, options);
    this.url = String(url || '').replace(/\/+$/, '');
    this.storageKey = 'phonebase_token_' + this.url;
    this.token = null;
    this.user = null;
    try { this.token = localStorage.getItem(this.storageKey); } catch (e) { /* abaikan */ }
  }

  var P = PhoneBase.prototype;

  P._save = function (t) {
    this.token = t || null;
    try {
      if (t) localStorage.setItem(this.storageKey, t); else localStorage.removeItem(this.storageKey);
    } catch (e) { /* abaikan */ }
  };

  P._headers = function (extra) {
    var h = extra || {};
    if (this.token) h['Authorization'] = 'Bearer ' + this.token;
    return h;
  };

  P._req = async function (method, path, body) {
    var opt = { method: method, headers: this._headers() };
    if (body !== undefined) {
      opt.headers['Content-Type'] = 'application/json';
      opt.body = JSON.stringify(body);
    }
    var r = await fetch(this.url + path, opt);
    var data = null;
    try { data = await r.json(); } catch (e) { /* bukan JSON */ }
    if (!r.ok) {
      var err = new Error((data && data.error) || ('HTTP ' + r.status));
      err.status = r.status;
      throw err;
    }
    return data;
  };

  // ---------------------------------------------------------- auth
  P.register = async function (email, password) {
    var r = await this._req('POST', '/api/auth/register', { email: email, password: password });
    this._save(r.token);
    this.user = r.user;
    return r.user;
  };

  P.login = async function (email, password) {
    var r = await this._req('POST', '/api/auth/login', { email: email, password: password });
    this._save(r.token);
    this.user = r.user;
    return r.user;
  };

  P.logout = async function () {
    try { await this._req('POST', '/api/auth/logout'); } catch (e) { /* abaikan */ }
    this._save(null);
    this.user = null;
  };

  P.me = function () { return this._req('GET', '/api/auth/me'); };

  P.changePassword = async function (oldPassword, newPassword) {
    var r = await this._req('POST', '/api/auth/password', { old: oldPassword, 'new': newPassword });
    this._save(r.token);
  };

  // ---------------------------------------------------------- database
  P.collection = function (name) {
    var self = this;
    // name boleh berupa path sub-koleksi, mis. 'users/ID/banks'
    var base = '/api/db/' + String(name).split('/').filter(Boolean).map(encodeURIComponent).join('/');
    return {
      list: function (opts) {
        opts = opts || {};
        var q = [];
        (opts.where || []).forEach(function (w) { q.push('where=' + encodeURIComponent(w)); });
        if (opts.order) q.push('order=' + encodeURIComponent(opts.order));
        if (opts.limit != null) q.push('limit=' + opts.limit);
        if (opts.offset != null) q.push('offset=' + opts.offset);
        return self._req('GET', base + (q.length ? '?' + q.join('&') : ''));
      },
      get: function (id) { return self._req('GET', base + '/' + encodeURIComponent(id)); },
      add: function (data) { return self._req('POST', base, data); },
      set: function (id, data) { return self._req('PUT', base + '/' + encodeURIComponent(id), data); },
      update: function (id, data) { return self._req('PATCH', base + '/' + encodeURIComponent(id), data); },
      remove: function (id) { return self._req('DELETE', base + '/' + encodeURIComponent(id)); },
      listen: function (callback) {
        var es = new EventSource(self.url + '/api/realtime?col=' + encodeURIComponent(name) +
          '&token=' + encodeURIComponent(self.token || ''));
        es.addEventListener('doc', function (e) { callback(JSON.parse(e.data)); });
        return function () { es.close(); };
      }
    };
  };

  // ---------------------------------------------------------- channel pesan
  P.channel = function (name) {
    var self = this;
    return {
      publish: function (message) {
        return self._req('POST', '/api/channels/' + encodeURIComponent(name) + '/publish', { message: message });
      },
      listen: function (callback) {
        var es = new EventSource(self.url + '/api/realtime?channel=' + encodeURIComponent(name) +
          '&token=' + encodeURIComponent(self.token || ''));
        es.addEventListener('msg', function (e) { callback(JSON.parse(e.data)); });
        return function () { es.close(); };
      }
    };
  };

  // ---------------------------------------------------------- file
  P.uploadFile = async function (file) {
    var r = await fetch(this.url + '/api/files?name=' + encodeURIComponent(file.name), {
      method: 'POST',
      headers: this._headers({ 'Content-Type': file.type || 'application/octet-stream' }),
      body: file
    });
    var data = null;
    try { data = await r.json(); } catch (e) { /* abaikan */ }
    if (!r.ok) throw new Error((data && data.error) || ('HTTP ' + r.status));
    return data;
  };

  P.fileUrl = function (id, download) {
    return this.url + '/api/files/' + encodeURIComponent(id) + '?token=' + encodeURIComponent(this.token || '') +
      (download ? '&download=1' : '');
  };

  P.listFiles = function () { return this._req('GET', '/api/files'); };
  P.deleteFile = function (id) { return this._req('DELETE', '/api/files/' + encodeURIComponent(id)); };

  global.PhoneBase = PhoneBase;
})(typeof window !== 'undefined' ? window : this);
