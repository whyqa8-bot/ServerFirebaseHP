(function () {
  'use strict';

  // ------------------------------------------------------------ util
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var enc = encodeURIComponent;
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var ORIGIN = location.origin;
  var token = '';
  try { token = localStorage.getItem('pb_admin') || ''; } catch (e) { /* abaikan */ }
  function saveToken(t) {
    token = t || '';
    try {
      if (token) localStorage.setItem('pb_admin', token); else localStorage.removeItem('pb_admin');
    } catch (e) { /* abaikan */ }
  }

  var S = { view: 'home', col: null, es: null, log: [], docOffset: 0, filter: '', docs: {} };

  var toastTimer = null;
  function toast(msg, bad) {
    var t = $('#toast');
    t.textContent = msg;
    t.style.background = bad ? 'var(--danger)' : 'var(--text)';
    t.style.color = bad ? '#fff' : 'var(--bg)';
    t.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.style.display = 'none'; }, 3200);
  }

  async function api(method, path, body) {
    var opt = { method: method, headers: {} };
    if (token) opt.headers['Authorization'] = 'Bearer ' + token;
    if (body !== undefined) {
      opt.headers['Content-Type'] = 'application/json';
      opt.body = JSON.stringify(body);
    }
    var r = await fetch(path, opt);
    var data = null;
    try { data = await r.json(); } catch (e) { /* bukan JSON */ }
    if (!r.ok) {
      if (r.status === 401 && token && path.indexOf('/api/admin/login') !== 0) {
        saveToken('');
        showLogin();
      }
      throw new Error((data && data.error) || ('HTTP ' + r.status));
    }
    return data;
  }

  function fmtBytes(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(1) + ' MB';
    return (n / 1073741824).toFixed(2) + ' GB';
  }
  function fmtTime(ts) { return ts ? new Date(ts).toLocaleString('id-ID') : '-'; }
  function fmtUp(ms) {
    var s = Math.floor(ms / 1000);
    var d = Math.floor(s / 86400); s -= d * 86400;
    var h = Math.floor(s / 3600); s -= h * 3600;
    var m = Math.floor(s / 60);
    return (d ? d + 'h ' : '') + h + 'j ' + m + 'm';
  }

  function closeStream() {
    if (S.es) { S.es.close(); S.es = null; }
  }

  function modal(title, bodyHtml, okText, onOk) {
    var m = $('#modal');
    m.innerHTML = '<div class="box"><h3 style="margin-top:0">' + esc(title) + '</h3><div>' + bodyHtml +
      '</div><div class="row end" style="margin-top:14px"><button class="ghost" id="mcancel">Batal</button>' +
      '<button id="mok">' + esc(okText || 'OK') + '</button></div></div>';
    m.style.display = 'flex';
    $('#mcancel').onclick = closeModal;
    $('#mok').onclick = async function () {
      try { await onOk(); } catch (e) { toast(e.message, true); }
    };
  }
  function closeModal() {
    var m = $('#modal');
    m.style.display = 'none';
    m.innerHTML = '';
  }
  function confirmBox(msg, onYes) {
    modal('Konfirmasi', '<p>' + esc(msg) + '</p>', 'Ya, lanjutkan', async function () {
      closeModal();
      await onYes();
    });
  }

  // ------------------------------------------------------------ login & shell
  function showLogin() {
    closeStream();
    $('#app').innerHTML =
      '<div class="login"><div class="card"><h2>PhoneBase</h2>' +
      '<p class="muted">Masuk sebagai admin. Password awal ada di aplikasi PhoneBase pada HP server.</p>' +
      '<form id="lf"><label>Password admin</label>' +
      '<input type="password" id="pw" autocomplete="current-password">' +
      '<div style="margin-top:12px"><button type="submit" style="width:100%">Masuk</button></div></form></div></div>';
    $('#lf').onsubmit = async function (e) {
      e.preventDefault();
      try {
        var r = await api('POST', '/api/admin/login', { password: $('#pw').value });
        saveToken(r.token);
        showApp();
      } catch (err) {
        toast(err.message, true);
      }
    };
  }

  var VIEWS = {
    home: ['Ringkasan', viewHome],
    db: ['Database', viewDb],
    users: ['Pengguna', viewUsers],
    files: ['File', viewFiles],
    rules: ['Aturan akses', viewRules],
    msg: ['Pesan realtime', viewMsg],
    settings: ['Pengaturan & panduan', viewSettings]
  };

  function showApp() {
    var nav = Object.keys(VIEWS).map(function (k) {
      return '<button data-v="' + k + '">' + esc(VIEWS[k][0]) + '</button>';
    }).join('');
    $('#app').innerHTML =
      '<header><span class="logo">PhoneBase</span><span class="srv">' + esc(ORIGIN) + '</span><span class="sp"></span>' +
      '<button class="ghost sm" id="logout">Keluar</button></header>' +
      '<nav id="nav">' + nav + '</nav><main id="view"></main>';
    $('#nav').onclick = function (e) {
      var b = e.target.closest('button[data-v]');
      if (b) go(b.getAttribute('data-v'));
    };
    $('#logout').onclick = async function () {
      try { await api('POST', '/api/auth/logout'); } catch (e) { /* abaikan */ }
      saveToken('');
      showLogin();
    };
    go(S.view);
  }

  function go(name) {
    closeStream();
    S.view = name;
    var btns = document.querySelectorAll('#nav button');
    for (var i = 0; i < btns.length; i++) {
      btns[i].className = btns[i].getAttribute('data-v') === name ? 'on' : '';
    }
    var el = $('#view');
    el.onclick = null;
    el.innerHTML = '<p class="muted">Memuat...</p>';
    VIEWS[name][1](el).catch(function (e) { toast(e.message, true); });
  }

  function statCard(label, value) {
    return '<div class="card stat"><div class="n">' + esc(value) + '</div><div class="l">' + esc(label) + '</div></div>';
  }

  // ------------------------------------------------------------ ringkasan
  async function viewHome(el) {
    var s = await api('GET', '/api/admin/stats');
    el.innerHTML = '<h2>Ringkasan</h2><div class="grid">' +
      statCard('Pengguna', s.users) + statCard('Dokumen', s.docs) + statCard('Koleksi', s.collections) +
      statCard('File', s.files) + statCard('Ukuran file', fmtBytes(s.fileBytes)) +
      statCard('Koneksi realtime', s.connections) + statCard('Total request', s.requests) +
      statCard('Server aktif', fmtUp(s.uptimeMs)) + '</div>' +
      '<h3>Aktivitas data (realtime)</h3><div class="card"><div class="log" id="log"></div></div>';
    renderLog();
    try {
      var es = new EventSource('/api/realtime?col=*&token=' + enc(token));
      es.addEventListener('doc', function (e) {
        var d = JSON.parse(e.data);
        S.log.unshift(new Date(d.ts).toLocaleTimeString('id-ID') + '  ' + d.type + '  ' + d.col + '/' + d.id);
        if (S.log.length > 100) S.log.pop();
        renderLog();
      });
      S.es = es;
    } catch (e) { /* abaikan */ }
  }
  function renderLog() {
    var l = $('#log');
    if (!l) return;
    l.innerHTML = S.log.length
      ? S.log.map(function (x) { return '<div>' + esc(x) + '</div>'; }).join('')
      : '<span class="muted">Belum ada aktivitas. Setiap perubahan dokumen akan muncul di sini secara langsung.</span>';
  }

  // ------------------------------------------------------------ database
  function cleanView(d) {
    var o = {};
    Object.keys(d || {}).forEach(function (k) {
      if (k !== 'id' && k.charAt(0) !== '_') o[k] = d[k];
    });
    return o;
  }

  async function viewDb(el) {
    var r = await api('GET', '/api/admin/collections');
    var cols = r.items;
    if (!S.col && cols.length) S.col = cols[0].name;
    if (S.col && !cols.some(function (c) { return c.name === S.col; })) {
      cols.push({ name: S.col, count: 0 });
    }
    el.innerHTML = '<h2>Database</h2><div class="split"><div class="cols">' +
      cols.map(function (c) {
        return '<button data-act="col" data-name="' + esc(c.name) + '" class="' + (c.name === S.col ? 'on' : '') + '">' +
          esc(c.name) + ' <span class="muted">(' + c.count + ')</span></button>';
      }).join('') +
      '<button class="ghost" data-act="newcol">+ Koleksi baru</button></div><div id="docs"></div></div>';
    el.onclick = function (e) {
      var b = e.target.closest('[data-act]');
      if (!b) return;
      var act = b.getAttribute('data-act');
      var id = b.getAttribute('data-id');
      if (act === 'col') {
        S.col = b.getAttribute('data-name');
        S.docOffset = 0;
        S.filter = '';
        viewDb(el);
      } else if (act === 'newcol') {
        modal('Koleksi baru', '<label>Nama koleksi (huruf, angka, _ - .)</label><input id="ncol" placeholder="contoh: produk">',
          'Buat', async function () {
            var n = $('#ncol').value.trim();
            if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/.test(n)) throw new Error('Nama koleksi tidak valid');
            S.col = n; S.docOffset = 0; S.filter = '';
            closeModal();
            viewDb(el);
          });
      } else if (act === 'newdoc') {
        editDoc(null);
      } else if (act === 'editdoc') {
        editDoc(id);
      } else if (act === 'deldoc') {
        confirmBox('Hapus dokumen ' + id + '?', async function () {
          await api('DELETE', '/api/db/' + enc(S.col) + '/' + enc(id));
          toast('Dokumen dihapus');
          viewDb(el);
        });
      } else if (act === 'delcol') {
        confirmBox('Hapus SEMUA dokumen di koleksi "' + S.col + '"? Tidak bisa dibatalkan.', async function () {
          await api('DELETE', '/api/admin/collections/' + enc(S.col));
          S.col = null;
          toast('Koleksi dihapus');
          viewDb(el);
        });
      } else if (act === 'filter') {
        S.filter = $('#flt').value.trim();
        S.docOffset = 0;
        loadDocs().catch(function (err) { toast(err.message, true); });
      } else if (act === 'prev') {
        S.docOffset = Math.max(0, S.docOffset - 20);
        loadDocs();
      } else if (act === 'next') {
        S.docOffset += 20;
        loadDocs();
      }
    };
    if (S.col) await loadDocs();
    else $('#docs').innerHTML = '<div class="card muted">Belum ada koleksi. Buat dengan tombol "+ Koleksi baru".</div>';
  }

  async function loadDocs() {
    var box = $('#docs');
    if (!box) return;
    var q = '?limit=20&offset=' + S.docOffset;
    if (S.filter) q += '&where=' + enc(S.filter);
    var r = await api('GET', '/api/db/' + enc(S.col) + q);
    S.docs = {};
    var html = '<div class="card"><div class="row"><b class="grow">' + esc(S.col) + '</b>' +
      '<button class="sm" data-act="newdoc">+ Dokumen</button>' +
      '<button class="sm danger" data-act="delcol">Hapus koleksi</button></div>' +
      '<div class="row" style="margin-top:10px"><input class="grow" id="flt" placeholder="Filter, mis. umur:gt:17 atau nama:contains:budi" value="' + esc(S.filter) + '">' +
      '<button class="sm" data-act="filter">Cari</button></div></div>';
    if (!r.items.length) html += '<div class="card muted" style="margin-top:8px">Tidak ada dokumen.</div>';
    r.items.forEach(function (d) {
      S.docs[d.id] = d;
      var txt = JSON.stringify(cleanView(d), null, 2);
      if (txt.length > 1200) txt = txt.substring(0, 1200) + '\n...';
      html += '<div class="card" style="margin-top:8px"><div class="row"><code class="grow">' + esc(d.id) + '</code>' +
        '<button class="sm ghost" data-act="editdoc" data-id="' + esc(d.id) + '">Edit</button>' +
        '<button class="sm danger" data-act="deldoc" data-id="' + esc(d.id) + '">Hapus</button></div>' +
        '<pre>' + esc(txt) + '</pre><div class="muted" style="font-size:12px">dibuat ' + esc(fmtTime(d._created)) +
        (d._owner ? ' &middot; pemilik ' + esc(d._owner) : '') + '</div></div>';
    });
    var from = r.count ? r.offset + 1 : 0;
    var to = Math.min(r.offset + r.limit, r.count);
    html += '<div class="row" style="margin-top:10px"><button class="sm ghost" data-act="prev"' + (r.offset <= 0 ? ' disabled' : '') + '>&laquo; Sebelumnya</button>' +
      '<span class="muted grow" style="text-align:center">' + from + '-' + to + ' dari ' + r.count + '</span>' +
      '<button class="sm ghost" data-act="next"' + (to >= r.count ? ' disabled' : '') + '>Berikutnya &raquo;</button></div>';
    box.innerHTML = html;
  }

  function editDoc(id) {
    var isNew = !id;
    var cur = isNew ? {} : cleanView(S.docs[id]);
    modal(isNew ? 'Dokumen baru' : 'Edit dokumen ' + id,
      '<textarea id="djson" spellcheck="false">' + esc(JSON.stringify(cur, null, 2)) + '</textarea>',
      'Simpan', async function () {
        var obj;
        try { obj = JSON.parse($('#djson').value); } catch (e) { throw new Error('JSON tidak valid'); }
        if (isNew) await api('POST', '/api/db/' + enc(S.col), obj);
        else await api('PUT', '/api/db/' + enc(S.col) + '/' + enc(id), obj);
        closeModal();
        toast('Tersimpan');
        viewDb($('#view'));
      });
  }

  // ------------------------------------------------------------ pengguna
  async function viewUsers(el) {
    var r = await api('GET', '/api/admin/users');
    var st = await api('GET', '/api/admin/stats');
    var rows = r.items.map(function (u) {
      return '<tr><td>' + esc(u.email) + '<div class="muted" style="font-size:12px">' + esc(u.id) + '</div></td>' +
        '<td>' + (u.disabled ? '<span class="tag bad">nonaktif</span>' : '<span class="tag ok">aktif</span>') + '</td>' +
        '<td>' + esc(fmtTime(u.created)) + '</td><td><div class="row">' +
        '<button class="sm ghost" data-act="toggle" data-id="' + esc(u.id) + '" data-dis="' + (u.disabled ? 0 : 1) + '">' + (u.disabled ? 'Aktifkan' : 'Nonaktifkan') + '</button>' +
        '<button class="sm ghost" data-act="pw" data-id="' + esc(u.id) + '" data-mail="' + esc(u.email) + '">Reset password</button>' +
        '<button class="sm danger" data-act="del" data-id="' + esc(u.id) + '" data-mail="' + esc(u.email) + '">Hapus</button></div></td></tr>';
    }).join('');
    el.innerHTML = '<h2>Pengguna</h2>' +
      '<div class="card"><div class="row"><input class="grow" id="ue" placeholder="email"><input class="grow" id="up" type="text" placeholder="password (min 6)">' +
      '<button id="uadd">Tambah user</button></div>' +
      '<label style="margin-top:12px"><input type="checkbox" id="reg" style="width:auto;margin-right:6px"' + (st.allowRegister ? ' checked' : '') + '> Izinkan pendaftaran mandiri lewat aplikasi (register)</label></div>' +
      '<div class="card tw" style="margin-top:10px"><table><thead><tr><th>Email</th><th>Status</th><th>Dibuat</th><th></th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="4" class="muted">Belum ada pengguna.</td></tr>') + '</tbody></table></div>';
    $('#uadd').onclick = async function () {
      try {
        await api('POST', '/api/admin/users', { email: $('#ue').value, password: $('#up').value });
        toast('User ditambahkan');
        viewUsers(el);
      } catch (e) { toast(e.message, true); }
    };
    $('#reg').onchange = async function () {
      try {
        await api('PUT', '/api/admin/settings', { allowRegister: $('#reg').checked });
        toast('Pengaturan disimpan');
      } catch (e) { toast(e.message, true); }
    };
    el.onclick = function (e) {
      var b = e.target.closest('[data-act]');
      if (!b) return;
      var act = b.getAttribute('data-act');
      var id = b.getAttribute('data-id');
      if (act === 'toggle') {
        api('PUT', '/api/admin/users/' + enc(id), { disabled: b.getAttribute('data-dis') === '1' })
          .then(function () { viewUsers(el); }).catch(function (err) { toast(err.message, true); });
      } else if (act === 'pw') {
        modal('Reset password ' + b.getAttribute('data-mail'), '<label>Password baru (min 6)</label><input id="npw">', 'Simpan', async function () {
          await api('PUT', '/api/admin/users/' + enc(id), { password: $('#npw').value });
          closeModal();
          toast('Password diganti');
        });
      } else if (act === 'del') {
        confirmBox('Hapus user ' + b.getAttribute('data-mail') + '?', async function () {
          await api('DELETE', '/api/admin/users/' + enc(id));
          toast('User dihapus');
          viewUsers(el);
        });
      }
    };
  }

  // ------------------------------------------------------------ file
  async function viewFiles(el) {
    var r = await api('GET', '/api/files');
    var rows = r.items.map(function (f) {
      var url = '/api/files/' + enc(f.id) + '?token=' + enc(token);
      var thumb = String(f.mime).indexOf('image/') === 0 ? '<img class="thumb" src="' + url + '" alt="">' : '';
      return '<tr><td>' + thumb + '</td><td>' + esc(f.name) + '<div class="muted" style="font-size:12px">' + esc(f.id) + '</div></td>' +
        '<td>' + esc(fmtBytes(f.size)) + '</td><td>' + esc(fmtTime(f.created)) + '</td><td><div class="row">' +
        '<a class="btn sm" style="text-decoration:none" href="' + url + '&download=1">Unduh</a>' +
        '<button class="sm danger" data-act="del" data-id="' + esc(f.id) + '" data-name="' + esc(f.name) + '">Hapus</button></div></td></tr>';
    }).join('');
    el.innerHTML = '<h2>File</h2><div class="card"><div class="row"><input type="file" id="fup" class="grow"><button id="fgo">Upload</button></div>' +
      '<p class="muted" style="margin:8px 0 0;font-size:12px">Maksimal 200 MB per file. Aplikasi bisa mengunggah lewat POST /api/files.</p></div>' +
      '<div class="card tw" style="margin-top:10px"><table><thead><tr><th></th><th>Nama</th><th>Ukuran</th><th>Diunggah</th><th></th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="5" class="muted">Belum ada file.</td></tr>') + '</tbody></table></div>';
    $('#fgo').onclick = async function () {
      var inp = $('#fup');
      if (!inp.files || !inp.files.length) { toast('Pilih file dulu', true); return; }
      var file = inp.files[0];
      try {
        toast('Mengunggah ' + file.name + '...');
        var resp = await fetch('/api/files?name=' + enc(file.name), {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': file.type || 'application/octet-stream' },
          body: file
        });
        var d = null;
        try { d = await resp.json(); } catch (e) { /* abaikan */ }
        if (!resp.ok) throw new Error((d && d.error) || ('HTTP ' + resp.status));
        toast('Upload selesai');
        viewFiles(el);
      } catch (e) { toast(e.message, true); }
    };
    el.onclick = function (e) {
      var b = e.target.closest('[data-act="del"]');
      if (!b) return;
      var id = b.getAttribute('data-id');
      confirmBox('Hapus file ' + b.getAttribute('data-name') + '?', async function () {
        await api('DELETE', '/api/files/' + enc(id));
        toast('File dihapus');
        viewFiles(el);
      });
    };
  }

  // ------------------------------------------------------------ aturan
  function opt(list, sel) {
    return list.map(function (x) { return '<option value="' + x + '"' + (x === sel ? ' selected' : '') + '>' + x + '</option>'; }).join('');
  }
  async function viewRules(el) {
    var r = await api('GET', '/api/admin/rules');
    var rows = r.items.map(function (x) {
      return '<tr><td><code>' + esc(x.key) + '</code></td><td>' + esc(x.read) + '</td><td>' + esc(x.write) + '</td><td><div class="row">' +
        '<button class="sm ghost" data-act="edit" data-key="' + esc(x.key) + '" data-r="' + esc(x.read) + '" data-w="' + esc(x.write) + '">Ubah</button>' +
        '<button class="sm danger" data-act="del" data-key="' + esc(x.key) + '">Hapus</button></div></td></tr>';
    }).join('');
    el.innerHTML = '<h2>Aturan akses</h2>' +
      '<div class="card"><p style="margin-top:0">Tanpa aturan, semua koleksi bisa dibaca dan ditulis oleh <b>user yang sudah login</b> (admin selalu bisa).</p>' +
      '<div class="row"><input class="grow" id="rk" placeholder="nama koleksi, _files, atau ch:namachannel">' +
      '<select id="rr" style="width:auto">' + opt(['public', 'auth', 'admin'], 'auth') + '</select>' +
      '<select id="rw" style="width:auto">' + opt(['public', 'auth', 'owner', 'admin'], 'auth') + '</select>' +
      '<button id="rsave">Simpan</button></div>' +
      '<p class="muted" style="font-size:12px;margin-bottom:0">Baca: public = siapa saja, auth = harus login, admin = hanya admin. ' +
      'Tulis: owner = hanya pembuat dokumen. <code>_files</code> mengatur file, <code>ch:nama</code> mengatur channel pesan.</p></div>' +
      '<div class="card tw" style="margin-top:10px"><table><thead><tr><th>Target</th><th>Baca</th><th>Tulis</th><th></th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="4" class="muted">Belum ada aturan khusus.</td></tr>') + '</tbody></table></div>';
    $('#rsave').onclick = async function () {
      var k = $('#rk').value.trim();
      if (!k) { toast('Isi nama target', true); return; }
      try {
        await api('PUT', '/api/admin/rules/' + enc(k), { read: $('#rr').value, write: $('#rw').value });
        toast('Aturan disimpan');
        viewRules(el);
      } catch (e) { toast(e.message, true); }
    };
    el.onclick = function (e) {
      var b = e.target.closest('[data-act]');
      if (!b) return;
      if (b.getAttribute('data-act') === 'edit') {
        $('#rk').value = b.getAttribute('data-key');
        $('#rr').value = b.getAttribute('data-r');
        $('#rw').value = b.getAttribute('data-w');
        $('#rk').focus();
      } else {
        var key = b.getAttribute('data-key');
        api('DELETE', '/api/admin/rules/' + enc(key))
          .then(function () { toast('Aturan dihapus'); viewRules(el); })
          .catch(function (err) { toast(err.message, true); });
      }
    };
  }

  // ------------------------------------------------------------ pesan
  async function viewMsg(el) {
    el.innerHTML = '<h2>Pesan realtime</h2><div class="card">' +
      '<label>Nama channel</label><input id="ch" value="umum">' +
      '<label>Pesan (teks atau JSON)</label><textarea id="mt" style="min-height:70px">halo dari dashboard</textarea>' +
      '<div class="row" style="margin-top:10px"><button id="msend">Kirim</button><button class="ghost" id="msub">Dengarkan channel</button></div></div>' +
      '<h3>Pesan masuk</h3><div class="card"><div class="log" id="mlog"><span class="muted">Tekan "Dengarkan channel" untuk melihat pesan yang masuk.</span></div></div>';
    $('#msend').onclick = async function () {
      var raw = $('#mt').value;
      var val = raw;
      try { val = JSON.parse(raw); } catch (e) { /* kirim sebagai teks */ }
      try {
        var r = await api('POST', '/api/channels/' + enc($('#ch').value.trim()) + '/publish', { message: val });
        toast('Terkirim ke ' + r.delivered + ' pendengar');
      } catch (e) { toast(e.message, true); }
    };
    $('#msub').onclick = function () {
      closeStream();
      var name = $('#ch').value.trim();
      var log = $('#mlog');
      log.innerHTML = '<div class="muted">Mendengarkan channel "' + esc(name) + '"...</div>';
      var es = new EventSource('/api/realtime?channel=' + enc(name) + '&token=' + enc(token));
      es.addEventListener('msg', function (e) {
        var d = JSON.parse(e.data);
        var line = document.createElement('div');
        line.textContent = new Date(d.ts).toLocaleTimeString('id-ID') + '  ' + (d.from || 'anon') + ': ' + JSON.stringify(d.message);
        log.insertBefore(line, log.children[1] || null);
      });
      S.es = es;
    };
  }

  // ------------------------------------------------------------ pengaturan
  async function viewSettings(el) {
    var js = [
      '<script src="' + ORIGIN + '/phonebase.js"></script>',
      '<script>',
      '  const pb = PhoneBase("' + ORIGIN + '");',
      '  await pb.register("user@mail.com", "rahasia123");   // atau pb.login(...)',
      '  const todos = pb.collection("todos");',
      '  await todos.add({ judul: "Beli susu", selesai: false });',
      '  const hasil = await todos.list({ where: ["selesai:eq:false"], order: "-_created" });',
      '  todos.listen(function (e) { console.log(e.type, e.id, e.data); });',
      '  pb.channel("umum").listen(function (m) { console.log(m.message); });',
      '</script>'
    ].join('\n');
    var curl = [
      'curl -X POST ' + ORIGIN + '/api/auth/login \\',
      '  -H "Content-Type: application/json" \\',
      '  -d \'{"email":"user@mail.com","password":"rahasia123"}\'',
      '',
      'curl ' + ORIGIN + '/api/db/todos -H "Authorization: Bearer TOKEN"',
      '',
      'curl -X POST ' + ORIGIN + '/api/db/todos \\',
      '  -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" \\',
      '  -d \'{"judul":"Beli susu"}\''
    ].join('\n');
    el.innerHTML = '<h2>Pengaturan & panduan</h2>' +
      '<div class="card"><b>Ganti password admin</b><div class="row" style="margin-top:8px"><input class="grow" id="apw" type="password" placeholder="password baru (min 8)">' +
      '<button id="asave">Simpan</button></div></div>' +
      '<h3>Alamat server</h3><div class="card"><code>' + esc(ORIGIN) + '</code>' +
      '<p class="muted" style="margin-bottom:0">Pakai alamat ini di aplikasi/situs Anda. Dari internet, gunakan alamat Tailscale atau Cloudflare Tunnel (lihat README).</p></div>' +
      '<h3>Contoh pakai (JavaScript)</h3><pre>' + esc(js) + '</pre>' +
      '<h3>Contoh pakai (curl)</h3><pre>' + esc(curl) + '</pre>' +
      '<h3>Endpoint ringkas</h3><div class="card tw"><table><tbody>' +
      '<tr><td><code>POST /api/auth/register</code></td><td>daftar user, balas token</td></tr>' +
      '<tr><td><code>POST /api/auth/login</code></td><td>login user, balas token</td></tr>' +
      '<tr><td><code>GET /api/db/{koleksi}</code></td><td>daftar dokumen (?where=f:op:v &amp;order= &amp;limit= &amp;offset=)</td></tr>' +
      '<tr><td><code>POST /api/db/{koleksi}</code></td><td>tambah dokumen</td></tr>' +
      '<tr><td><code>GET/PUT/PATCH/DELETE /api/db/{koleksi}/{id}</code></td><td>baca / ganti / gabung / hapus</td></tr>' +
      '<tr><td><code>GET /api/realtime?col=...&amp;token=...</code></td><td>stream perubahan dokumen (SSE)</td></tr>' +
      '<tr><td><code>GET /api/realtime?channel=...&amp;token=...</code></td><td>stream pesan channel</td></tr>' +
      '<tr><td><code>POST /api/channels/{nama}/publish</code></td><td>kirim pesan ke channel</td></tr>' +
      '<tr><td><code>POST /api/files?name=...</code></td><td>unggah file (body = isi file)</td></tr>' +
      '<tr><td><code>GET /api/files/{id}</code></td><td>ambil file</td></tr>' +
      '</tbody></table></div>';
    $('#asave').onclick = async function () {
      try {
        await api('POST', '/api/admin/password', { password: $('#apw').value });
        $('#apw').value = '';
        toast('Password admin diganti');
      } catch (e) { toast(e.message, true); }
    };
  }

  // ------------------------------------------------------------ mulai
  if (token) {
    api('GET', '/api/admin/stats').then(showApp).catch(function () { showLogin(); });
  } else {
    showLogin();
  }
})();
